# FinWeave — Project Charter

Ngày 05/10/2026; baseline `scope-v1`. Chủ sản phẩm là người giao nhiệm vụ trong chat; chưa có danh tính pháp nhân, nhà tài trợ, nhóm vận hành hoặc ngân sách được chỉ định. Đây là charter làm việc, không tự tạo phê duyệt tổ chức.

## Mục tiêu và quyền

Mục tiêu sản phẩm hiện chọn: chuẩn bị và tiến tới M1 cho bốn nhóm ngân hàng/ví, tiền mặt, cổ phiếu, vàng với thiết lập, thu thập/cập nhật, quản lý giao dịch, theo dõi và Review. Amendment quản trị v1.1: nhiệm vụ mới **hoàn thiện quản trị bước1 → thực hiện đủ bước2 → đánh giá gate rồi dừng**, theo D-12; scope-v1/18 REQ–AC giữ nguyên.

Quyền lần này: đọc workspace, tạo/sửa tài liệu, kiểm tra local bước2. Chưa giao thực hiện bước3, tích hợp thật, public deployment, billing hoặc mua dịch vụ. Phạm vi chi tiết và acceptance criteria nằm trong [Scope](scope.md); thay đổi bộ hồ sơ không đổi phạm vi tính năng.

## Deliverables và gate

| Mốc | Deliverables | Tiêu chí thoát |
|---|---|---|
| Bước 1 lần này | Vision, Problem, Value, Charter, Scope, Feasibility, Options, Cost, Assumptions/Constraints, Risks, Roadmap; thêm backlog và execution | Đủ artefact, bốn nhóm × năm chức năng, benefit/AC kiểm tra được, phần hoãn riêng, giả định/chi phí/rủi ro có nhãn; link/ID nhất quán |
| Bước 2 hiện được giao | Stakeholder Needs, Context Model, Operational Scenarios, PRD, SRS FR/NFR, Use Cases, Business Rules Catalogue, Data Requirements, Glossary, RTM; register và review | 18 REQ/AC bao phủ; UC đủ trường; rules/data/scenarios/oracle nhất quán; evidence review; external review pending |
| Bước 3 khi được giao | UX, prototype web tương tác local, review/demo guide/evidence | AC-01…18 kiểm tra được bằng mô phỏng, đủ desktop/mobile/keyboard; lỗi nghiêm trọng xử lý; báo đúng loại nghiên cứu |

## Trách nhiệm

| Vai trò | Trách nhiệm | Trạng thái |
|---|---|---|
| Chủ sản phẩm | Chọn mục tiêu/scope, phản hồi hồ sơ/prototype; quyết định chi phí, quyền dữ liệu và môi trường mới | User hiện tại |
| Agent thực hiện | Phân tích, tạo artefact, tự rà soát, giữ nguồn và báo trạng thái có bằng chứng | Được giao bước2; không reviewer độc lập |
| Người tham gia đánh giá | Chạy tác vụ giả, phản hồi mức hiểu | Chưa có; không giả định đã tuyển |
| Người phụ trách nguồn/security/Ops tương lai | Xác minh adapter/quyền/PoC/gate và vận hành | Chưa chỉ định; không có vai trò Ops trên prototype |

Các owner “Agent” ở risk/backlog là trách nhiệm chuẩn bị/kiểm tra trong bước được giao; không tự gán người thật hoặc cam kết nguồn lực tương lai.

## Ràng buộc, thay đổi và thành công

Không deadline cụ thể hoặc ngân sách tiền xác nhận. Roadmap dựa trên gate, cost model là ước lượng sơ bộ. Dùng dữ liệu giả, tiếng Việt/VND/+07:00, responsive web local. Không sửa nguồn yêu cầu để làm scope tự phù hợp kết quả.

Khi có thay đổi: ghi yêu cầu mới → đánh giá tác động tới scope/AC/backlog/phụ thuộc/chi phí → cập nhật decisions và baseline. Tài liệu mở rộng lần này đã được user yêu cầu; Budget/Goals/Alerts/Assistant vẫn `out-of-scope`. Nếu chưa có user test, chỉ báo walkthrough và giới hạn chưa kiểm chứng nhu cầu. Bước 1 xong không đồng nghĩa M1 đạt.
