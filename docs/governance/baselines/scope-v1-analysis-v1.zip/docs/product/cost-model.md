# FinWeave — Cost Model sơ bộ

Ngày 05/10/2026. Đơn vị: giờ công và VND. **Ước lượng lập kế hoạch, chưa có time log, đơn giá, báo giá hoặc budget được user chốt.** Đây không là báo giá/cam kết; hiệu suất Agent và thời gian người rà soát chưa đo. Không dùng giá dịch vụ hiện hành chưa xác minh.

## 1. Effort phần còn lại tới M1

Bước 1 đang bàn giao được tách khỏi effort còn lại để tránh tính hai lần. Chi phí đã bỏ ra không biết vì chưa có time log; không suy từ thời gian chat hoặc token thành giờ công.

| Gói công việc | Backlog | Low / Base / High (giờ công giả định) | Điều kiện ước lượng |
|---|---|---:|---|
| Gói10 artefact bước2: Needs/Context/Scenarios/PRD/SRS/UC/Rules/Data/Glossary/RTM | BL-02…06 | 6 / 9 / 12 | Ước lượng lịch sử chưa actual, giữ scope/oracle; sau bước2 cần tái ước lượng phần còn lại, không coi estimate là time log |
| IA, wireframe, tokens, UX spec | BL-07 | 4 / 6 / 8 | Một hướng thiết kế chính, một vòng phản hồi |
| Prototype setup/cập nhật/giao dịch/dashboard/Review | BL-08…09 | 12 / 18 / 26 | Fixture local, không backend/collector/provider |
| Walkthrough, sửa lỗi, evidence và demo guide | BL-10 | 6 / 9 / 14 | Desktop/mobile/keyboard, không mở rộng tính năng |
| **Tổng cơ sở còn lại** | BL-02…10 | **28 / 42 / 60** | Chưa có thời gian user review/chờ |

BL-11 user test có điều kiện: thêm 4/6/10 giờ công giả định chuẩn bị/thực hiện/tổng hợp nếu tuyển được người; không bao gồm thời gian chờ hoặc phí người tham gia. Không tự loại user test khỏi báo cáo: nếu chưa làm phải ghi chưa kiểm chứng.

## 2. Biến và công thức chi phí

| Biến | Giá trị hiện tại | Ý nghĩa |
|---|---|---|
| H_core | 28 / 42 / 60 giờ giả định | Effort cơ sở còn lại |
| H_user | 0 khi chưa tổ chức; 4 / 6 / 10 khi có test | Effort user test; không phải số giờ thực tế |
| r | Chưa chốt, VND/giờ | Đơn giá quy đổi giờ công; nếu nhiều vai trò dùng tổng H_i×r_i |
| c | Đề xuất 20%, chưa chốt | Dự phòng rework trong scope; không dùng cho thêm module |
| C_tools, C_participants | Chưa xác nhận | License/tài khoản thử, phí người tham gia nếu chọn |
| C_infra, C_provider, C_deploy | Không đưa vào nhu cầu M1 local/mock | Nếu phát sinh phải chọn riêng, không tự trả phí |
| H_review, capacity | Chưa biết | Effort rà soát của user và năng lực giờ hữu ích/ngày |

`H_plan = (H_core + H_user) × (1 + c)`

`C_remaining = Σ(H_i × r_i) + C_tools + C_participants + C_infra + C_provider + C_deploy`

Nếu dùng một đơn giá cho effort đã dự phòng: `C_labor = H_plan × r`; không cộng khoản dự phòng labor lần nữa. Tổng dự án = chi phí bước 1 thực tế (chưa biết) + chi phí còn lại + công việc khác được chọn; không mặc định các khoản chưa biết bằng 0.

| Kịch bản lập kế hoạch với c=20% | H_plan | Chi phí labor bằng biến r |
|---|---:|---|
| Low, chưa có user test | 33,6 giờ | 33,6 × r |
| Base, chưa có user test | 50,4 giờ | 50,4 × r |
| High, chưa có user test | 72 giờ | 72 × r |
| Base, thêm user test 6 giờ | 57,6 giờ | 57,6 × r + phí test được chọn |

Không điền tổng VND khi r và khoản mua ngoài chưa biết. M1 không yêu cầu mua hạ tầng hay gọi API, nhưng thiết bị/công cụ sẵn có không tự đồng nghĩa tổng chi phí kinh tế bằng 0.

## 3. Lịch, độ nhạy và cập nhật

Ngày làm hữu ích ước tính = H_plan / capacity; thời gian lịch còn cộng thời gian chờ phản hồi/người tham gia. Chưa có capacity/deadline nên [roadmap](roadmap.md) không hẹn ngày. Base + 20% effort cơ sở do rework sẽ là 50,4 giờ cơ sở trước dự phòng; dùng mô hình để đánh giá thay đổi, không tự coi là actual.

Rủi ro tăng effort: thêm nghiệp vụ mua/bán đầy đủ, tăng mẫu nguồn, thêm module tùy chọn, thiếu rules và nhiều vòng UX. Thay đổi này cần cập nhật backlog/AC/ước lượng; phần dự phòng không cấp quyền mở rộng.

M2/M3 chưa có tổng chi phí khả tín. Cần cấu phần frontend/tests, backend/worker/storage, protected boundary/key service, source license/quota, vận hành/restore và security verification; chỉ lập giá tiền sau khi có kiến trúc/quyền/báo giá. Không suy chi phí SaaS từ một máy chủ hay “free API” trong Ideas.
