# FinWeave — Backlog từ phạm vi M1

Baseline `scope-v1`, version 1.1, 05/10/2026. Nguồn: [scope](scope.md), Playbook bước 1–3; nhiệm vụ hiện tại bước 2. P0 = bắt buộc cho mốc tương ứng; P1 = hỗ trợ/giảm rủi ro; P2 = mở rộng chưa chọn. Bước 3/M2/M3 chưa được giao thực hiện.

## 1. Thứ tự và đầu ra có thể nghiệm thu

| ID | Priority / mức / bước | Công việc và đầu ra | REQ / AC | Phụ thuộc | Trạng thái |
|---|---|---|---|---|---|
| BL-01 | P0 / chuẩn bị M1 / 1 | Kiểm kê workspace; bộ hồ sơ 11 artefact chuyên nghiệp theo README, backlog và execution; kiểm tra phạm vi/link/ID/số | Tất cả REQ, AC-01…18 | Ba tài liệu + nhiệm vụ + yêu cầu bổ sung | `verified` về tài liệu bước 1; xem evidence |
| BL-02 | P0 / M1 / 2 | Viết use cases setup đủ ngân hàng, ví, cash, cổ phiếu, vàng; trường/validation/mốc/nhánh hủy | SET/BANK/CASH-01/STOCK/GOLD; AC-01…05 | BL-01, OD-01/02/04 dùng mặc định | `verified` về đặc tả/tài liệu; EVD-S2-001, sản phẩm vẫn planned |
| BL-03 | P0 / M1 / 2 | UC nhập thu–chi/chuyển/refund, CSV, source demo, cash count, lượng/giá; nêu thay đổi trước–sau | INPUT/MONEY/CASH-02/HOLD; AC-06…10 | BL-02, OD-03/04 | `verified` về đặc tả/tài liệu; EVD-S2-001, sản phẩm vẫn planned |
| BL-04 | P0 / M1 / 2 | UC giao dịch/override/adjustment, Tổng quan/drill-down/phạm vi, từng loại Review | TXN/TRACK/REVIEW; AC-11…16 | BL-02/03 | `verified` về đặc tả/tài liệu; EVD-S2-001, sản phẩm vẫn planned |
| BL-05 | P0 / M1 / 2 | Business Rules Catalogue + Data Requirements/dictionary + Glossary; trạng thái riêng, giả định OD; SRS gồm 18 FR và NFR đo/đánh giá được | Tất cả REQ; AC-01…18 | BL-02…04, nguồn Ideas + oracle | `verified` về đặc tả/tài liệu; EVD-S2-001, sản phẩm vẫn planned |
| BL-06 | P0 / M1 / 2 | Stakeholder Needs, Context Model, PRD; Operational Scenarios/reset/expected độc lập; RTM/register/decisions/evidence; gate bước 2 | Tất cả AC | BL-05, OD-02/04 | `verified` về đặc tả/tài liệu; EVD-S2-001, sản phẩm vẫn planned |
| BL-07 | P0 / M1 / 3 | IA, wireframes, tokens, ux-spec: câu hỏi→visual→drill-down; trạng thái thiếu/cũ/lỗi/empty | TRACK/UX; AC-13…17 | BL-02…06 | `planned` |
| BL-08 | P0 / M1 / 3 | Web prototype local setup và cập nhật đủ bốn nhóm; reset/state demo thống nhất | SET/BANK/CASH/STOCK/GOLD/INPUT/MONEY/HOLD/DEMO; AC-01…10,18 | BL-07; chọn công cụ local khi xây | `planned` |
| BL-09 | P0 / M1 / 3 | Giao dịch, category/posted adjustment, dashboard và Review tương tác; mọi tác động theo cùng scenario | TXN/TRACK/REVIEW; AC-11…16 | BL-08 | `planned` |
| BL-10 | P0 / M1 / 3 | Walkthrough đủ AC desktop/mobile/keyboard; sửa lỗi nghiêm trọng, ghi prototype-review, ảnh và demo script/cách mở | UX/DEMO; AC-01…18 | BL-08/09 | `planned` |
| BL-11 | P1 / M1 / 3 | Thử tác vụ với người tham gia nếu có; ghi mẫu, trợ giúp, câu trả lời, vấn đề; nếu không thì nêu chưa user test | UP-01…05, A-01…03 | BL-10, OD-01 + người tham gia | `planned`, chưa có người tham gia |

BL-02…06 là gói bước 2 đã được giao: Use Cases trong BL-02…04; Rules/Data/Glossary/SRS trong BL-05; Needs/Context/Scenarios/PRD/RTM trong BL-06, đủ 10 artefact Playbook. BL-07…11 là gói bước 3 chưa thực hiện; đánh giá M1 ở BL-10 và báo giới hạn nghiên cứu ở BL-11. Không yêu cầu BL-11 có kết quả giả để vượt gate.

## 2. Công việc tiếp nối có điều kiện, chưa được giao

| ID | Priority khi được giao / mức | Đầu ra và lợi ích | Phụ thuộc / gate | Trạng thái hiện tại |
|---|---|---|---|---|
| FUT-01 | P0 / M2 bước 4–6 | Frontend-spec, logical API/transport, mock mutation/error/version/reset; frontend/tests/handover | Baseline M1; DEP-04 khảo sát boundary trước chốt transport | `planned`, hoãn thực hiện |
| FUT-02 | P1 / trước M2 transport và M3 dữ liệu thật | Threat model/PoC phạm vi Ops, ingress/egress, key policy/code/client/auth/recovery, chi phí | Nguồn Ideas 15–16; OD-07; hạ tầng/quyền riêng | `planned`, không là gate M1 |
| FUT-03 | P0 / M3 bước 7–9 | Backend ledger/worker/Engine, atomic/idempotency, workspace, tích hợp và restore có bằng chứng | FUT-01/02; budget/môi trường được cấp; gate security | `planned`, chưa tích hợp |
| FUT-04 | P1 / M3 nguồn | Chọn CSV/provider giá hợp lệ, thử mẫu/quota/license; nêu capability hỗ trợ | OD-05/06, DEP-01…03; nguồn thật chỉ sau gate security | `planned`, chưa xác minh bởi nhiệm vụ này |
| FUT-05 | P2 / nếu chọn thêm | Collector Android, thêm adapter/PDF/OCR/SMS/email, sync holdings | Scope riêng + permission/license/mẫu kiểm thử | `out-of-scope` hiện tại |
| EXT-01 | P2 / nếu chọn | Budget với actual/refund/unclassified từ Engine | Nhiệm vụ mới + rule/báo cáo | `out-of-scope` |
| EXT-02 | P2 / nếu chọn | Goals/phân bổ/scenario, không cộng trùng tài sản | Nhiệm vụ mới + Engine/allocation rules | `out-of-scope` |
| EXT-03 | P2 / nếu chọn | Alerts/inbox/ngưỡng/dedupe và thông báo an toàn | Nhiệm vụ mới + quyền kênh/rules | `out-of-scope` |
| EXT-04 | P2 / nếu chọn | Assistant/tools/evaluation/provider phù hợp loại dữ liệu | Nhiệm vụ mới; privacy/quota; không mặc định Gemini nhận thật | `out-of-scope` |
| EXT-05 | P2 / nếu chọn | BĐS/vốn kinh doanh/nợ/thẻ/đa tiền tệ/hộ gia đình/export/rule nâng cao | Scope + mô hình nghiệp vụ/quyền riêng | `out-of-scope` |

## 3. Phụ thuộc cần theo dõi

| ID | Phụ thuộc / điều chưa biết | Cách xử lý M1 | Cần giải quyết lúc nào / bằng chứng | Việc liên quan |
|---|---|---|---|---|
| DEP-01 | Ngân hàng/ví và mẫu thông báo/sao kê, Android permission; web/iOS không có collector tương đương mặc định | CSV và thông báo fixture giả, không công bố tên nguồn hỗ trợ thật | Trước chọn adapter thật: mẫu có quyền, version/độ trễ/thiếu/trùng/lỗi | BL-03/06, FUT-04/05 |
| DEP-02 | Provider cổ phiếu, key cá nhân quyền đọc, quota/phí/license SaaS | DEMO-A + key dummy, không gọi API | Trước tích hợp: tài khoản được cấp quyền, điều khoản/key handling; SSI chỉ là ứng viên trong nguồn | BL-03/06, FUT-04 |
| DEP-03 | Nguồn vàng, loại sản phẩm/buy-sell/đơn vị/purity; FX/time/license | Quote VND/chỉ giả chính; nhánh quốc tế/FX giả để kiểm tra thiếu/sai | Trước định giá thật: xác minh nguồn, đơn vị, license, timestamp; không tự coi giá quốc tế là giá thu mua nội địa | BL-03/05/06, FUT-04 |
| DEP-04 | Công nghệ boundary bảo vệ, key policy độc lập Ops, client/auth/recovery và chi phí | Ghi yêu cầu chưa kiểm chứng; không triển khai crypto để đạt M1 | Khảo sát trước chốt transport M2; PoC và toàn gate Ideas 15 trước thật | FUT-01/02/03 |
| DEP-05 | Nhóm user đầu, ba câu hỏi hằng tuần, người tham gia/rubric bài nộp | Giả định rõ; web tương tác local tiếng Việt đã được chọn | Trước đánh giá nhu cầu/khả năng hiểu: user test thật; rubric thêm chỉ khi được cung cấp | BL-02/07/11 |
| DEP-06 | Kỳ demo, stale policy, định dạng CSV mẫu, loại quote và rounding | Dùng mặc định OD-02…04; ghi version fixture/reset | Chốt trong rules/scenarios bước 2; không cần backend/provider | BL-05/06 |

Không kiểm tra web/provider thật trong bước 1; các nhận định API của Ideas được giữ như thông tin nguồn cần tái xác minh ở tích hợp, không phải bằng chứng mới. Không có blocker ngăn bàn giao bước 1 hoặc bắt đầu bước 2 bằng mặc định đã ghi.
