# FinWeave — Phạm vi chuẩn bị M1

Ngày lập: 05/10/2026 (Asia/Saigon). Baseline: `scope-v1`. Trạng thái: bước 1 đã lập phạm vi theo nhiệm vụ; các chức năng sản phẩm `planned`, chưa nghiệm thu M1.

## 1. Căn cứ và ranh giới nhiệm vụ

- [Ideas](../../FinWeave_Ideas.md): mục 1–9, 14–21 là nguồn nghiệp vụ; nhãn brainstorm không tự biến mọi module thành phạm vi được chọn.
- [Playbook](../../FinWeave_Agent_Execution_Playbook.md): mục 3–4 quy định bước 1; mục 5–6 quy định đầu vào bước 2 và gate M1; mục 13 cung cấp oracle giả.
- [Hướng dẫn](../../FinWeave_Human_Setup_and_Prompts.md): mục 2 và Prompt 1.
- Nhiệm vụ hiện tại chỉ thực hiện **bước 1**, chuẩn bị cho M1: ngân hàng/ví, tiền mặt, cổ phiếu, vàng; thiết lập, thu thập/cập nhật, quản lý giao dịch, theo dõi và Review.
- Giao diện tiếng Việt, responsive web, dữ liệu tổng hợp. Hướng bàn giao M1: prototype web tương tác chạy local, có reset. Lần này chỉ tạo tài liệu; chưa xây prototype, backend hoặc API contract.
- Budget, Goals, Alerts, Assistant chưa đưa vào lần bàn giao này. Không tự triển khai nguồn thật, collector Android, dịch vụ trả phí, billing hoặc public deployment.

## 2. Hiện trạng và môi trường

Workspace là thư mục chứa ba tài liệu nguồn. Kiểm kê ban đầu không thấy code, package manifest, lockfile, test, docs/execution hoặc quy định AGENTS.md áp dụng trong workspace và các thư mục cha đã kiểm tra. Git báo đây không phải repository. Không có bằng chứng tính năng đã xây hoặc nghiên cứu user đã làm.

PROJECT_ROOT: thư mục hiện tại; IDEA_SOURCE: `FinWeave_Ideas.md`; TARGET_LEVEL: M1; STEP_RANGE lần này: 1; DATA_MODE: synthetic. Chưa chọn stack/package manager/lệnh chạy app; không cần cài môi trường ở bước 1. Tiền hiển thị VND, timezone nghiệp vụ `Asia/Ho_Chi_Minh` (+07:00). Demo chỉ một chủ workspace, không có chia sẻ hay vai trò Ops trong UI.

Thiết bị đánh giá đề xuất: desktop 1440×900, mobile 390×844 và kiểm tra chiều rộng 360px; đây là mục tiêu cho bước 3, chưa phải kết quả đã kiểm tra.

## 3. Nhóm user và vấn đề cần kiểm chứng

**Toàn bộ nhóm user, tần suất và lợi ích dưới đây là giả thuyết sản phẩm từ Ideas, chưa có phỏng vấn, khảo sát hay usability test.** Không suy thị trường mục tiêu từ thư mục học phần của workspace.

| ID | Nhóm dự kiến / vấn đề | Câu hỏi cần trả lời | Chức năng / lợi ích mong đợi | Cách kiểm chứng sau này |
|---|---|---|---|---|
| UP-01 | Cá nhân có tiền ở nhiều ngân hàng/ví và tiền mặt; phải tự cộng | Tiền đang ở đâu, tổng tiền theo dõi là bao nhiêu? | Thiết lập và Tổng quan; thấy tiền và tài sản trong cùng phạm vi | Tác vụ thiết lập, đọc tổng và chỉ ra tài khoản đóng góp |
| UP-02 | Cá nhân dùng tiền mặt, thường bỏ sót khoản chi | Khoản chi vừa ghi ảnh hưởng thế nào; tiền kiểm đếm có khớp? | Nhập nhanh, kiểm đếm; biết chênh lệch thay vì tự coi dữ liệu đủ | Ghi chi và đối chiếu số tính/kiểm đếm |
| UP-03 | Cá nhân có cổ phiếu/vàng khai báo; nhầm giá mới với danh mục mới | Tôi có bao nhiêu, giá từ đâu, thông tin nào đã cũ? | Tách lượng/giá/ngày; hiểu giá trị tham chiếu và giới hạn | Đổi riêng giá rồi riêng lượng, giải thích tác động |
| UP-04 | Cá nhân muốn biết khoản chi lớn, thiếu nhóm hoặc khó tìm căn cứ | Nhóm nào chi nhiều; giao dịch nào tạo tổng? | Bộ lọc, phân loại, drill-down; tìm và sửa dữ liệu liên quan | Mở thanh chi tiêu tới đúng giao dịch và quay lại |
| UP-05 | Cá nhân nhập nhiều nguồn, gặp trùng/chuyển/refund chưa rõ | Giao dịch này có bị đếm hai lần; xác nhận thay đổi gì? | Preview và Review; kiểm tra bằng chứng trước khi sửa | Xử lý nghi trùng/transfer, so kết quả trước–sau |

Giả định A-01: một chủ workspace là actor chính, có thể khai báo holdings; A-02: ưu tiên ba câu hỏi hằng tuần “tiền ở đâu / chi vào gì / dữ liệu nào cần kiểm tra”; A-03: user cần cả mobile và desktop. Cần kiểm chứng các giả định với người tham gia trước khi dùng làm kết luận về nhu cầu. Không có người tham gia vẫn có thể tự walkthrough nhưng phải ghi đúng loại đánh giá.

## 4. Định nghĩa mức và ánh xạ nhãn prototype

M1 chứng minh tác vụ, cách đọc visual và phản hồi bằng mô phỏng. M2 chứng minh frontend gọi lớp API theo contract, mutation và lỗi qua mock. M3 chứng minh frontend/backend thật, dữ liệu bền vững, nghiệp vụ, quyền, privacy và vận hành trong môi trường công bố. **Các cột M2/M3 dưới đây là hướng tiếp nối có điều kiện, chưa được giao triển khai.** Roadmap ba giai đoạn của Ideas không đồng nghĩa M1/M2/M3.

| Nội dung mang nhãn prototype trong Ideas | M1 của nhiệm vụ này | Công việc chuyển sang mức phù hợp |
|---|---|---|
| Identity, isolation, thiết bị (mục 2) | Workspace demo và mốc theo dõi; không cần đăng ký/reset mật khẩu | Auth/session contract M2; xác thực, isolation và recovery thật M3 |
| CSV commit, job, parser, retry (mục 4) | Wizard fixture, preview, confirm, lỗi và kết quả mô phỏng nhất quán | API/job mock M2; parser, worker, transaction và idempotency thật M3 |
| Double-entry/atomic/reversal/ownership (mục 5) | Tác động thu–chi/chuyển/refund và dấu vết sửa thể hiện trên UI | Contract trạng thái M2; ledger cân bằng và quyền backend M3 |
| Matching, rules, Engine, snapshot (mục 6–8) | Kịch bản đã biết kết quả; category thủ công, Review, dashboard cùng số | Mock theo contract M2; matching/Engine/version thực M3 |
| Dashboard có Budget/Goals; Agent (mục 8–13) | Chỉ visual lõi đã chọn; bốn phần tùy chọn ngoài bàn giao | Chỉ thêm khi có nhiệm vụ chọn rõ; không mặc định vào M2/M3 |
| Envelope encryption, DB dump, console Ops (mục 15–17) | Ghi yêu cầu và phụ thuộc; dùng giả, không tuyên bố đã chống Ops | PoC boundary khảo sát sớm trước chốt transport M2; kiểm chứng đầy đủ ở M3 trước dữ liệu thật |

State/fixture trong bộ nhớ hoặc lưu local để demo được phép ở M1, có nhãn/reset. Không gọi đó là ledger chính thức hay bằng chứng lưu backend. Không yêu cầu PostgreSQL, LLM key, API giá hoặc hạ tầng mã hóa để chứng minh luồng giao diện.

## 5. Scope matrix M1/M2/M3 theo chức năng

Ký hiệu: **mô phỏng** = trong M1; **hỗ trợ mock** = dự kiến M2 khi được giao; **thật có điều kiện** = dự kiến M3 sau quyền/gate; **hoãn** = giữ hướng sản phẩm nhưng không bắt buộc; **ngoài phạm vi** = chưa chọn trong nhiệm vụ.

| REQ | Chức năng và user benefit | M1 hiện chọn | M2 tiếp nối | M3 tiếp nối | AC |
|---|---|---|---|---|---|
| REQ-SET-01 | Mốc theo dõi/workspace demo; biết kỳ và phạm vi dữ liệu | Mô phỏng, VND/+07:00 | Hỗ trợ mock cấu hình/session | Thật có điều kiện auth/quyền | AC-01 |
| REQ-BANK-01 | Tạo ngân hàng và ví; thấy số dư/nguồn riêng | Mô phỏng cả hai loại | Hỗ trợ mock CRUD/archive | Thật có điều kiện lưu/quyền | AC-02 |
| REQ-CASH-01 | Tạo ví tiền mặt; biết tiền tự khai báo | Mô phỏng | Hỗ trợ mock CRUD | Thật có điều kiện | AC-03 |
| REQ-STOCK-01 | Khai báo mã/thị trường/lượng/giá vốn; biết giá trị tham chiếu | Mô phỏng | Hỗ trợ mock holdings | Thật có điều kiện; lượng khai báo, giá provider | AC-04 |
| REQ-GOLD-01 | Khai báo loại/purity/khối lượng; tránh sai đơn vị và nguồn giá | Mô phỏng | Hỗ trợ mock holdings/quotes | Thật có điều kiện nguồn/đơn vị/FX | AC-05 |
| REQ-INPUT-01 | Đưa sao kê vào, kiểm tra trước khi ghi nhận | Mô phỏng CSV mẫu và ánh xạ cột | Hỗ trợ mock preview/confirm/job | Thật có điều kiện parser/commit | AC-06 |
| REQ-INPUT-02 | Cập nhật từ nguồn, biết khi lỗi/cũ/mất quyền | Mô phỏng thông báo và nguồn giá, dummy connection | Hỗ trợ mock connection/retry | Thật có điều kiện nguồn; collector riêng nếu chọn | AC-07 |
| REQ-MONEY-01 | Nhập thu/chi ngân hàng/ví/tiền mặt, chuyển nội bộ/phí/refund | Mô phỏng form và kết quả | Hỗ trợ mock mutations | Ledger thật có điều kiện | AC-08 |
| REQ-CASH-02 | Kiểm đếm, phát hiện và xử lý chênh lệch có lý do | Mô phỏng | Hỗ trợ mock preview/resolve | Thật có điều kiện adjustment/audit | AC-09 |
| REQ-HOLD-01 | Cập nhật lượng và giá riêng; biết vì sao định giá đổi | Mô phỏng khai báo/điều chỉnh có ngày/lý do | Hỗ trợ mock movements/quotes | Thật có điều kiện; liên kết dòng tiền khi đủ dữ liệu | AC-10 |
| REQ-TXN-01 | Tìm giao dịch và xem nguồn/bằng chứng/trạng thái | Mô phỏng filter/detail | Hỗ trợ mock query/pagination | Thật có điều kiện protected search | AC-11 |
| REQ-TXN-02 | Sửa draft/category hoặc điều chỉnh posted có dấu vết | Mô phỏng thao tác từng giao dịch | Hỗ trợ mock version/conflict | Thật có điều kiện reversal/override | AC-12 |
| REQ-TRACK-01 | Tổng quan tiền, thu–chi, dòng tiền, cơ cấu bốn nhóm | Mô phỏng cùng oracle/snapshot | Hỗ trợ mock reports | Engine thật có điều kiện | AC-13 |
| REQ-TRACK-02 | Mở căn cứ từ visual, giữ ngữ cảnh/phạm vi | Mô phỏng drill-down, scope on/off/archive | Hỗ trợ mock filters/invalidation | Thật có điều kiện report version | AC-14 |
| REQ-REVIEW-01 | Kiểm tra nghi vấn tiền trước khi xác nhận | Mô phỏng thiếu trường/trùng/transfer/refund/category/pending/lệch | Hỗ trợ mock resolve/version | Thật có điều kiện matching/transaction | AC-15 |
| REQ-REVIEW-02 | Kiểm tra chất lượng holdings/giá/nguồn | Mô phỏng cũ/thiếu/không khớp, dẫn tới cập nhật | Hỗ trợ mock quality cases | Thật có điều kiện dữ liệu nguồn | AC-16 |
| REQ-UX-01 | Đọc và thao tác tiếng Việt trên web/mobile/bàn phím | Hỗ trợ UI + state mô phỏng | Frontend hoàn chỉnh với mock | Giữ UX trên dữ liệu thật | AC-17 |
| REQ-DEMO-01 | Biết đây là demo, mở/reset và lặp lại tác vụ | Hỗ trợ demo local | Demo mode tách thật, mock reset | Demo tách môi trường thật | AC-18 |

### Bao phủ bốn nhóm × năm chức năng

| Nhóm | Thiết lập | Thu thập/cập nhật | Quản lý giao dịch/sự kiện | Theo dõi | Review |
|---|---|---|---|---|---|
| Ngân hàng/ví | BANK-01 (cả ngân hàng và ví) | INPUT-01/02, MONEY-01 | TXN-01/02, chuyển/phí/refund | TRACK-01/02 | REVIEW-01/02 |
| Tiền mặt | CASH-01 | MONEY-01, CASH-02 | TXN-01/02, rút/nộp là transfer | TRACK-01/02 | CASH-02, REVIEW-01 |
| Cổ phiếu | STOCK-01 | HOLD-01, INPUT-02 | Lịch sử khai báo/điều chỉnh lượng có ngày/lý do; không là tiền vào giả | TRACK-01/02 | REVIEW-02 |
| Vàng | GOLD-01 | HOLD-01, INPUT-02 | Lịch sử thay đổi khối lượng có ngày/lý do, giữ đơn vị | TRACK-01/02 | REVIEW-02 |

ID rút gọn trong bảng trên có tiền tố `REQ-`. Với cổ phiếu/vàng, M1 cần lịch sử sự kiện lượng sở hữu và một ví dụ liên kết mua với tiền nếu có đủ dữ liệu; không bao gồm đặt lệnh, đồng bộ holdings thật, corporate-action engine hay tính hiệu quả đầu tư đầy đủ.

### Phần chưa chọn — giữ riêng, không tự chuyển thành scope tương lai

| Chức năng | M1 lần này | M2/M3 | Hệ quả UI / điều kiện mở lại |
|---|---|---|---|
| Budget (Ideas 10) | `out-of-scope` | Chưa chọn | Không có card/ngưỡng/form ngân sách; thêm bằng nhiệm vụ riêng |
| Goals (Ideas 11) | `out-of-scope` | Chưa chọn | Không phân bổ, timeline mục tiêu, mô phỏng mua sắm |
| Alerts (Ideas 12) | `out-of-scope` | Chưa chọn | Không inbox/push/email/rule nhắc; status nguồn và số case Review vẫn thuộc lõi |
| Assistant (Ideas 13) | `out-of-scope` | Chưa chọn | Không chat, tool calling, canned AI hay Gemini key |
| BĐS, vốn kinh doanh, nợ/thẻ tín dụng, đa tiền tệ tài khoản, hộ gia đình | `out-of-scope` | Chưa chọn | Không dùng nhãn tài sản ròng đầy đủ; thêm cần mô hình/rule/phạm vi riêng |
| Collector Android/iOS, SMS/email, PDF/OCR, API nguồn thật | Hoãn tích hợp; chỉ mock nguồn đã chọn | M2 mock; M3 chọn riêng adapter có quyền | Web không giả vờ tự đọc thông báo điện thoại |
| Category/rule cá nhân, batch action, export CSV/PDF, widget tùy chỉnh | Hoãn | Chưa chọn mở rộng | M1 dùng category hệ thống và sửa từng mục; không có nút giả hoạt động |
| Đăng ký/MFA/reset/recovery, console Ops, billing | Ngoài luồng M1 | Auth/privacy/vận hành cần cho M3; billing chưa chọn | Không dùng route guard/demo để tuyên bố đã phân quyền/mã hóa |

## 6. Acceptance criteria M1 có thể kiểm tra

Tất cả AC sau là **mục tiêu nghiệm thu tại bước 3, chưa chạy/chưa pass**. Mỗi tác vụ reset về đúng scenario trước khi đo; form phải mở/nhập/kiểm tra/xác nhận/hủy và trả kết quả mô phỏng. Lỗi mô phỏng ghi đúng demo, không chứng minh cơ chế backend.

| AC | Tác vụ / dữ liệu đầu vào | Kết quả quan sát phải đạt |
|---|---|---|
| AC-01 | Vào demo mới, chọn mốc theo dõi rồi mở Tổng quan; quay lại demo đã có dữ liệu | Hiện VND, kỳ và +07:00; opening không là thu nhập; lần sau mở Tổng quan trực tiếp, không buộc xử lý Review |
| AC-02 | Tạo ngân hàng 20 triệu và ví 0 VND ở cùng mốc; thử bỏ tên/số tiền sai; hủy form | Hai thẻ khác loại, số dư/ngày/nguồn rõ; 0 đã khai báo khác thiếu số dư; lỗi không tạo mục, hủy không đổi tổng |
| AC-03 | Tạo tiền mặt 2 triệu; bỏ số dư rồi thử lại | Nhãn tự khai báo; số dư tính toán khác số kiểm đếm; chưa kiểm đếm là chưa có dữ liệu, không là 0 |
| AC-04 | Khai báo DEMO-A/thị trường DEMO, 100 cổ phiếu, giá giả 50.000 VND/cổ phiếu; không nhập giá vốn | Giá trị 5 triệu, lượng/ngày khai báo và giá/ngày giá riêng; lãi/lỗ chưa xác định; thiếu thị trường hoặc lượng âm bị chặn |
| AC-05 | Khai báo vàng nhẫn demo 9999, 5 chỉ, quote giả 8 triệu VND/chỉ; đổi display sang 0,5 lượng | Giá trị 40 triệu ở cả hai cách biểu diễn; hiện loại/purity/nguồn/đơn vị/ngày. Quote quốc tế có nhãn quốc tế và FX riêng; thiếu FX hoặc sai loại thì chưa thể định giá, không bằng 0 |
| AC-06 | Chọn sao kê CSV giả, tài khoản đích và cột; preview có dòng hợp lệ, thiếu trường, nghi trùng | Thấy gốc/chuẩn hóa/lỗi và số dòng được phép; hủy không đổi số; confirm chỉ phần hợp lệ đã chọn, phần nghi vấn vào Review. Xác nhận lại cùng batch mô phỏng không tăng giao dịch; có lịch sử kết quả demo |
| AC-07 | Chọn nguồn thông báo demo rồi quote demo; bật scenario lỗi/mất quyền/cũ và thử lại | Nêu loại dữ liệu nguồn lấy được, thời điểm và hành động; không yêu cầu key thật; quote mới không đổi holdings, lỗi không thành giá 0, retry có kết quả mô phỏng |
| AC-08 | Theo baseline, ghi chi cash 150.000, chuyển ngân hàng→ví 2 triệu, rút ngân hàng→cash 1 triệu; mở refund 200.000 liên kết mua 600.000 | Chi cash làm tiền mặt 3 triệu→2,85 triệu; chuyển/rút không thành thu–chi sinh hoạt; refund là sự kiện riêng ngày nhận; phí fixture riêng là chi. Bỏ số tiền/tài khoản/ngày bắt buộc, số tiền ≤0 và hủy không ghi nhận |
| AC-09 | Khi cash tính 2,85 triệu, kiểm đếm 2,8 triệu cùng mốc | Hiện lệch −50.000, chưa tự tạo chi; bổ sung giao dịch hoặc xác nhận điều chỉnh có lý do/preview/lịch sử; hủy giữ nguyên số tính |
| AC-10 | Đổi riêng giá DEMO-A 50.000→55.000 và vàng 8→8,2 triệu/chỉ; sau reset đổi lượng cổ phiếu 100→110 | Đổi giá làm tài sản cuối kỳ 76,1→77,6 triệu; tiền 31,1 triệu và thu–chi giữ nguyên. Đổi lượng tại giá 50.000 làm holdings 5→5,5 triệu, lưu ngày/lý do và nhãn khai báo; không tự tạo income/expense. Với ví dụ mua mới đủ căn cứ, tiền đầu tư và tăng holdings liên kết, không đếm mua thành chi sinh hoạt |
| AC-11 | Lọc kỳ/tài khoản/loại/category/trạng thái; mở DEMO-06, rồi mở pending fixture | Danh sách đúng bộ lọc; detail có số tiền/ngày/tài khoản/evidence/lịch sử; posting, reconciliation và category là trạng thái riêng; pending tách khỏi tổng posted; không tìm thấy có empty state |
| AC-12 | Sửa draft, đổi category DEMO-08; điều chỉnh posted cash 150.000→120.000 trong scenario riêng | Draft chưa tác động tổng; đổi category không đổi tổng chi 1,1 triệu; sửa posted có preview, gốc/đảo/thay thế hoặc adjustment liên kết, lý do và dấu vết. Cash tăng lại 30.000 đúng một lần; hủy không đổi; import lại mô phỏng giữ override |
| AC-13 | Chạy đủ DEMO-01…08 từ opening, rồi xem Tổng quan | Khớp oracle mục 7; tiền tách giá trị tài sản. Bar chi gồm ăn uống 400.000, mua hàng gộp 600.000/hoàn 200.000, chưa phân loại 100.000; visual có kỳ/đơn vị/nhãn và bảng thay thế |
| AC-14 | Click Ăn uống, click cổ phiếu, Back; tắt ví khỏi phạm vi rồi archive trong scenario riêng | Mở đúng DEMO-04/05 hoặc holding, giữ kỳ/phạm vi khi quay lại. Bỏ ví: tiền cuối kỳ 29,35 triệu, dòng tiền của ngân hàng+cash 7,35 triệu do transfer sang ví ra khỏi phạm vi; giải thích ranh giới. Archive không xóa lịch sử; thiếu quote không giả tổng đầy đủ |
| AC-15 | Mở từng case trùng, transfer thiếu một phía, refund chưa liên kết, thiếu trường, chưa phân loại, pending lâu, lệch số dư | Có căn cứ/đề xuất/tác động trước–sau và lựa chọn phù hợp xác nhận/từ chối/bổ sung/hủy. Gộp evidence thứ hai DEMO-06 không đổi oracle; xác nhận cùng case lần nữa không đổi số. Hai bản ghi cùng tiền/ngày không tự gộp; thiếu phía nhận không tự tăng tiền đích |
| AC-16 | Mở case holdings cũ, giá cũ/thiếu, FX thiếu, quote vàng sai loại; cập nhật hoặc từ chối | Phân biệt ngày lượng/ngày giá; giải thích phần chưa định giá; dẫn tới form/nguồn đúng. Giữ quote cũ có nhãn và thời điểm; không tạo độ chính xác/bao phủ % giả; xác nhận user không thành xác minh độc lập |
| AC-17 | Walkthrough ở 1440×900, 390×844, rộng 360px và chỉ bàn phím; bật ẩn số tiền | Tiếng Việt nhất quán; không chồng/cắt nội dung hay cuộn ngang toàn trang; form/visual đọc và bấm được. Focus rõ, dialog đóng/quay focus đúng, lỗi có chữ, màu không là tín hiệu duy nhất, chart có bảng; privacy che giá trị cả card/chart/detail |
| AC-18 | Mở theo hướng dẫn local, chạy scenario thành công/lỗi rồi Reset | Demo có nhãn giá/ngày/dữ liệu giả, không nút tùy chọn gây hiểu đang hoạt động; reset khôi phục opening, nguồn/case/giá và bộ lọc nhất quán; demo script lặp lại được, ghi rõ cách lưu local nếu có |

## 7. Bộ số kiểm tra và quy tắc giữ nguyên

Nguồn số: Playbook mục 13. Baseline: ngân hàng 20.000.000, ví 0, cash 2.000.000; cổ phiếu 100×50.000 = 5.000.000; vàng 5 chỉ×8.000.000 = 40.000.000 VND. Tiền đầu kỳ 22.000.000; tài sản theo dõi 67.000.000.

| Sau DEMO-01…08 | VND kỳ vọng |
|---|---:|
| Ngân hàng / ví / cash | 26.500.000 / 1.750.000 / 2.850.000 |
| Tổng tiền | 31.100.000 |
| Thu nhập / chi gộp / refund / chi thuần | 10.000.000 / 1.100.000 / 200.000 / 900.000 |
| Dòng tiền ròng ba tài khoản tiền | +9.100.000 |
| Tài sản theo dõi giá ban đầu / sau đổi giá | 76.100.000 / 77.600.000 |

Nguyên tắc bắt buộc cho bước 2: opening không cộng hai lần; original và reversal cùng được tính theo dấu; pending/draft không thành posted; chưa phân loại vẫn tính khoản hợp lệ. Refund giảm chi ở kỳ nhận, có fixture khác kỳ. Transfer phụ thuộc ranh giới tài khoản tiền, phí riêng. Thiếu dữ liệu không thành 0. Không gọi tổng bốn nhóm là tài sản ròng đầy đủ. Lượng holdings/giá/FX/nguồn/độ mới là các thông tin độc lập; thay giá không là dòng tiền hoặc thu nhập.

Các nhánh bổ sung cần bước 2 mô tả: refund nhiều lần/khác kỳ/vượt mua; transfer một phía/có phí/ngoài phạm vi; opening/reversal; cash lệch; quote/FX thiếu/cũ/sai đơn vị; source revision và override; mất quyền/lỗi nguồn; xung đột sửa và retry. M1 mô phỏng nhánh quan trọng; bộ lỗi HTTP/concurrency và chứng minh idempotency thật thuộc M2/M3.

## 8. Mục tiêu kiểm chứng và gate M1 sau này

- Mục tiêu: 18/18 AC có kịch bản và bằng chứng walkthrough ở bước 3; toàn bộ số trong oracle khớp; mọi chỉ số chính có đường về dữ liệu căn cứ; đủ bốn nhóm × năm chức năng.
- Mục tiêu: 0 lỗi nghiêm trọng còn mở làm tác vụ chính không hoàn thành hoặc khiến hiểu sai số tiền/nguồn; lỗi nhỏ ghi tác động và kế hoạch sửa trong prototype-review.
- Nếu có user test: đề xuất 5 người thuộc nhóm giả định, ít nhất 4/5 hoàn thành độc lập các tác vụ chính; đọc được tiền/tài sản, khoản chi lớn, ngày lượng versus ngày giá và dữ liệu chưa rõ; ghi thời gian, trợ giúp và câu trả lời. Cỡ mẫu/ngưỡng này là đề xuất chưa chốt, chưa đo, không chứng minh đại diện thị trường.
- Nếu chưa có người tham gia: báo chỉ tự walkthrough, mức hiểu của user chưa kiểm chứng; không viết “đã phỏng vấn” hoặc tỷ lệ hoàn thành giả.
- Bước 1 hoàn thành khi scope/benefit/AC/backlog/phụ thuộc/traceability đủ cho bước 2. Điều đó **không đồng nghĩa đạt M1**; M1 cần thêm use cases, rules, thiết kế và prototype chạy được.

## 9. Phụ thuộc, quyết định và đầu vào bước 2

Xem [backlog](backlog.md) và [decisions](../execution/decisions.md). Quyết định còn mở ảnh hưởng gần: nhóm user/người tham gia, kỳ demo/ngưỡng cũ, mẫu CSV/loại quote vàng. Đã có mặc định đề xuất để viết bước 2; không cần khóa kế hoạch vì chưa có provider thật. Quyết định nguồn/quyền key, FX/license và kiến trúc chống Ops ảnh hưởng tích hợp sau này, không là điều kiện dựng M1.

Bước 2 phải tạo đủ Stakeholder Needs, Context Model, Operational Scenarios, PRD, SRS (functional requirements + NFR), Use Cases, Business Rules Catalogue, Data Requirements (gồm dictionary nghiệp vụ), Glossary và RTM theo Playbook §3.5/5; lấy REQ/AC làm baseline, giữ ID UC/SCN dự kiến trong traceability hoặc cập nhật mapping khi tách. Actor chính là chủ workspace demo. Màn hình dự kiến: Thiết lập; Tài khoản & Tài sản (tiền/cổ phiếu/vàng); Nguồn dữ liệu/Import; Ghi thu–chi/Chuyển/Refund; Giao dịch/Chi tiết; Tổng quan; Kiểm tra dữ liệu. Không thêm Kế hoạch/Trợ lý/Inbox Alerts.

Mỗi UC cần điều kiện/trigger, các bước user/hệ thống, thành công/thiếu/trùng/hủy/pending/nguồn cũ/mất quyền/xung đột và hậu điều kiện theo mức. Dictionary cần account, holding/movement, source record/evidence, event, quote, review case, report snapshot; rules cần tiền/đơn vị/ngày, opening/transfer/refund/reversal, nguồn sự thật và các trục trạng thái riêng. Bước 2 chưa cần OpenAPI hoặc backend.

Amendment quản trị 05/10/2026, v1.1 trên `scope-v1`: các mục “lần này chỉ bước 1” ở §1–2 là bối cảnh tạo baseline lịch sử. Nhiệm vụ mới cho phép bước 2 rồi dừng sau gate; 18 REQ/AC, phạm vi chức năng và oracle không thay đổi. Baseline phân tích dẫn xuất là `analysis-v1`, chưa sign-off bên ngoài.
