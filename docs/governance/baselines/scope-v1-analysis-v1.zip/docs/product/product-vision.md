# FinWeave — Product Vision

Ngày 05/10/2026. Nguồn: Ideas mục 1, 20; phạm vi thực hiện: [scope-v1](scope.md). Đây là hướng sản phẩm và giả thuyết cần kiểm chứng.

## Tầm nhìn

FinWeave giúp cá nhân nhìn tài chính phân tán thành một bức tranh có thể kiểm tra: biết tiền đang ở đâu, chi vào gì, lượng tài sản đã khai báo được định giá thế nào và dữ liệu nào cần bổ sung. Mọi số tổng hợp cần có đường truy về căn cứ và giới hạn dữ liệu.

User dự kiến là người tự quản lý tài chính cá nhân, có ngân hàng/ví và tiền mặt, có thể nắm cổ phiếu/vàng. Đây là A-01, chưa xác nhận qua nghiên cứu; không khẳng định mọi user đều sở hữu đủ bốn nhóm.

## Kết quả mong muốn và nguyên tắc

| Kết quả | Cách thể hiện trong M1 | Dấu hiệu kiểm chứng dự kiến |
|---|---|---|
| Hiểu tiền/tài sản trong phạm vi theo dõi | Tổng quan bốn nhóm, tiền tách khỏi tài sản cần bán | Đọc đúng tiền 31,1 triệu và tài sản 76,1 triệu của scenario |
| Hiểu nguyên nhân biến động | Thu–chi/dòng tiền/định giá tách nghĩa; drill-down | Tìm được giao dịch đóng góp; giá tăng không thành thu nhập |
| Chủ động kiểm tra dữ liệu | Source/time/unit, Review có preview | Nhận ra dữ liệu cũ/thiếu, biết xác nhận làm thay đổi gì |
| Có nền để phát triển tiếp | REQ→UC→màn hình→contract/test/evidence | Bước 2 không phải tự đoán lại phạm vi hoặc quy tắc quan trọng |

Ưu tiên trung thực về dữ liệu, visual dẫn tới hành động, chủ dữ liệu quyết định điều chỉnh, và privacy trước dữ liệu thật. Giá trị này chưa chứng minh ưu thế thị trường hoặc khả năng bảo mật thực tế.

## Tầm nhìn dài hạn và mốc hiện tại

Hướng dài hạn trong Ideas là SaaS backend trung tâm, nguồn được cấp quyền, ledger/Engine chính thức và bảo vệ tài chính khỏi Ops. Kế hoạch/AI/tài sản mở rộng chỉ được thêm khi lựa chọn phạm vi rõ và đủ điều kiện.

M1 hiện tại kiểm chứng trải nghiệm bằng dữ liệu giả trên responsive web tiếng Việt. Không đặt mục tiêu realtime, tự động bao phủ mọi tài sản, doanh thu/retention hay khuyến nghị đầu tư cho mốc này. Chỉ số sau M1 có thể nghiên cứu: thời gian ra câu trả lời hữu ích, số thao tác nhập/sửa, khả năng hiểu nguồn số và mức quay lại sử dụng; chưa có baseline để đặt cam kết kinh doanh.
