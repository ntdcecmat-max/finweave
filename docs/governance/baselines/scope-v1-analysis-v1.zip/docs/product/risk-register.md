# FinWeave — Risk Register

Ngày 05/10/2026. Xác suất và tác động là đánh giá định tính phục vụ lập kế hoạch, chưa đo: thấp/vừa/cao. Owner là vai trò dự kiến, không gán người chưa được chỉ định. Tất cả rủi ro còn theo dõi; biện pháp trong tài liệu chưa chứng minh rủi ro đã được loại bỏ.

| ID | Rủi ro / trigger | Xác suất / tác động / ưu tiên | Owner | Biện pháp, việc liên quan | Phần dư / thời điểm rà soát |
|---|---|---|---|---|---|
| R-01 | Hiểu “prototype” Ideas là phải xây ledger/DB thật trước UI; backlog bắt đầu thêm backend | Cao / cao / P0 | Agent + chủ sản phẩm | Ánh xạ Scope mục 4; D-04; BL-01/02 | Review phạm vi đầu bước 2 và trước xây; M1 chưa đạt |
| R-02 | Thiếu nhóm hoặc chỉ import→dashboard; cash/holdings/Review không có tác vụ | Vừa / cao / P0 | Agent | Matrix 4×5, REQ/AC; BL-02…06 và BL-10 | Rà use cases rồi walkthrough đủ nhóm |
| R-03 | State/chart/detail lệch, transfer/refund/giá bị đếm sai | Cao / cao / P0 | Agent | Oracle độc lập, fixture/reset, rules và scenario; AC-08…15 | Bước 2 rules, bước 3 sau từng mutation; M3 cần Engine thật |
| R-04 | Persona/value hoặc tỷ lệ user test được viết như nghiên cứu đã làm | Vừa / cao / P0 | Agent + chủ sản phẩm | A-01…04 và UP có nhãn; BL-11 chỉ khi có người | Nhu cầu vẫn chưa kiểm chứng nếu chỉ walkthrough |
| R-05 | Unknown/stale/self-declared bị hiểu thành 0/mới/xác minh; vàng quốc tế thành giá thu mua | Vừa / cao / P0 | Agent | Source/time/unit/purity/FX labels, AC-04/05/07/16 | Rà quote và empty/partial totals ở bước 2–3 |
| R-06 | Responsive/keyboard chỉ đẹp ở desktop; mobile form/chart bị cắt | Vừa / vừa / P1 | Agent | AC-17, BL-07/10; focus/error/table thay chart | Kiểm tra thật ở ba viewport khi có prototype |
| R-07 | Hồ sơ mở rộng kéo theo thêm tính năng Budget/AI hoặc backend | Cao / cao / P0 | Chủ sản phẩm + Agent | Charter: đổi artefact không đổi feature scope; EXT tách riêng | Kiểm tra mỗi yêu cầu thay đổi; chi phí rework vẫn có thể tăng |
| R-08 | Effort/deadline vượt kỳ vọng; estimate bị coi là báo giá | Vừa / cao / P1 | Chủ sản phẩm + người thực hiện | EST-01, model low/base/high, chưa hẹn ngày; cập nhật sau bước 2 | Chưa có capacity/actual/đơn giá nên còn bất định |
| R-09 | Provider/key/quota/license không phù hợp SaaS hoặc format thay đổi | Chưa biết / cao / P1 tương lai | Vai trò nguồn chưa chỉ định | DEP-01…03, FUT-04; mock M1, xác minh mẫu/terms trước thật | M3 nguồn chưa được chọn, không cản M1 |
| R-10 | Encryption thông thường bị coi đã chống Ops; transport phải đổi sau M2 | Cao / rất cao / P0 tương lai | Vai trò security chưa chỉ định | OD-07/DEP-04/FUT-02; PoC sớm trước contract; gate Ideas 15 | Chưa có PoC/budget, M3 thật chưa đủ điều kiện |
| R-11 | Dữ liệu thật/key vô tình đưa vào demo/repo/log/LLM | Vừa / cao / P0 | Agent + chủ sản phẩm | CON-03/05/07, synthetic/dummy only; Assistant ngoài scope | Kiểm tra fixture/evidence trước chia sẻ; không mở nguồn thật |
| R-12 | Rubric/định dạng bàn giao khác dự kiến, cần làm lại | Chưa biết / vừa / P1 | Chủ sản phẩm | OD-01/UNK-02; hướng web tiếng Việt đã chốt; không suy rubric từ folder | Khi có rubric, đánh giá tác động và cập nhật charter |

Các issue hiện hữu: chưa có app, user research, nguồn tích hợp, security PoC; đây là trạng thái thực tế theo mức chứ chưa là blocker bước 1. Khi trigger xảy ra, ghi defect/issue cụ thể và tác động gate trong progress; không chỉ giảm mức rủi ro vì đã có tài liệu.
