# FinWeave — Bộ hồ sơ bước 1–2

Baseline `scope-v1` bước 1, `analysis-v1` bước 2; cập nhật05/10/2026, version1.1. Vẫn chuẩn bị M1 cho bốn nhóm lõi. Hồ sơ tự rà soát, pending external review; chưa đạt M1, không thay nghiên cứu hoặc prototype evidence.

| Artefact | File / câu hỏi được giải quyết |
|---|---|
| Product Vision | [product-vision.md](product-vision.md) — hướng sản phẩm, user dự kiến và thước đo giá trị |
| Problem Statement | [problem-statement.md](problem-statement.md) — vấn đề nào cần giải quyết và còn thiếu bằng chứng gì |
| Value Proposition | [value-proposition.md](value-proposition.md) — chức năng đem lại lợi ích nào, chứng minh bằng cách nào |
| Project Charter | [project-charter.md](project-charter.md) — mục tiêu, quyền, trách nhiệm, deliverables, gate |
| Scope | [scope.md](scope.md) — M1/M2/M3, bốn nhóm × năm chức năng, AC và phần chưa chọn |
| Feasibility Study | [feasibility-study.md](feasibility-study.md) — khả thi sơ bộ và điều kiện chưa kiểm chứng |
| Options Analysis | [options-analysis.md](options-analysis.md) — phương án bàn giao và lý do chọn |
| Cost Model | [cost-model.md](cost-model.md) — effort, biến chi phí, công thức và kịch bản |
| Assumptions/Constraints | [assumptions-constraints.md](assumptions-constraints.md) — điều đã chốt, điều giả định, cách xác minh |
| Risk Register | [risk-register.md](risk-register.md) — rủi ro, trigger, owner, biện pháp và phần dư |
| Roadmap | [roadmap.md](roadmap.md) — mốc theo gate, phụ thuộc và điều kiện mở rộng |
| Backlog | [backlog.md](backlog.md) — công việc cụ thể, priority, output và dependency |

Đọc Charter → Problem/Vision/Value → Scope → Feasibility/Options/Cost/Risks → Roadmap/Backlog. Bước 2 dùng Scope, Assumptions, Decisions và Traceability làm nguồn trực tiếp. Hồ sơ execution: [plan](../execution/plan.md), [progress](../execution/progress.md), [decisions](../execution/decisions.md), [traceability](../execution/traceability.md), [evidence bước 1](../execution/evidence/step-1-review.md).

## Gói bước 2 — đủ theo Playbook

| Artefact / ID | Nguồn sự thật |
|---|---|
| Stakeholder Needs / PRD-NEED-001 | [stakeholder-needs.md](stakeholder-needs.md) — nhu cầu giả định và người cần review |
| Context Model / REQ-CTX-001 | [context-model.md](../requirements/context-model.md) — actors, ranh giới, interfaces |
| Operational Scenarios / REQ-SCN-001 | [operational-scenarios.md](operational-scenarios.md) — 18 scenario chính, 12 nhánh và oracle/reset |
| PRD / PRD-001 | [prd.md](prd.md) — mục tiêu/benefit/scope/gate |
| SRS FR + NFR / REQ-SRS-001 | [srs.md](../requirements/srs.md) — 18 FR baseline, 11 NFR mục tiêu |
| Use Cases / REQ-UC-001 | [use-cases.md](use-cases.md) — 18 UC đầy đủ trường/nhánh |
| Business Rules Catalogue / REQ-BR-001 | [business-rules.md](business-rules.md) — 24 rules, states và assumptions |
| Data Requirements / DAT-REQ-001 | [data-requirements.md](../data/data-requirements.md) — 15 nhóm dữ liệu/dictionary/lineage |
| Glossary / REQ-GLO-001 | [glossary.md](../requirements/glossary.md) — nghĩa thuật ngữ và nhãn Việt |
| RTM / REQ-RTM-001 | [traceability.md](../execution/traceability.md) — needs/REQ/UC/SCN/AC/rules/data/NFR tới screen/API/test/evidence |

Quản trị: [Artifact Register](../governance/artifact-register.md); bằng chứng và gate: [Step2 Review](../execution/evidence/step-2-review.md). Đọc Needs/Context/PRD → SRS/UC → Rules/Data/Glossary → Scenarios/RTM. IDs và đường dẫn trong register là nguồn catalogue; không tạo `data-dictionary.md` riêng cạnh Data Requirements để tránh hai nguồn sự thật.
