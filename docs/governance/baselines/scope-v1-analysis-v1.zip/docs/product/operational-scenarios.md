# FinWeave — Operational Scenarios

ID REQ-SCN-001 · v1.0 · analysis-v1/scope-v1 · 05/10/2026 · in-review. Agent owner/self-review; PO pending external review. Nguồn [Playbook §13](../../FinWeave_Agent_Execution_Playbook.md), [Scope](scope.md), [Rules](business-rules.md), [Use Cases](use-cases.md). **Scenario và fixture specification với expected tính độc lập; chưa phải fixture app hoặc kết quả user test.**

## Reset và clock giả

OD-02/03/04 là **giả định được phép dùng**. Kỳ tháng 10: [01/10 00:00, 01/11 00:00) +07; clock demo 31/10/2026 18:00 +07. Kỳ tháng 11 chỉ trong SCN-X05, clock 30/11 18:00. Ngày sau 05/10 là thời gian hư cấu, không dữ liệu thực tương lai. QuantityAsOf 01/10 18:00, quoteAt 31/10 17:00: tuổi đúng 30 ngày và 1 giờ chưa stale theo ngưỡng strict >. Opening 01/10 00:00; source baseline lastSuccess 31/10 17:00. Quote hiện tại dùng định giá opening positions trong bộ số, không khẳng định giá lịch sử ngày opening.

| Fixture | Reset baseline |
|---|---|
| F-EMPTY | Workspace mới, chưa settings/accounts/holdings/events/cases; clock và kỳ mặc định để chọn. Không coi no accounts là số đo 0 |
| F-BASE | Bank 20m, wallet 0, cash 2m; stock 100×50k; gold 5 chỉ×8m. Chưa DEMO events. Tiền 22m; opening positions theo quote baseline 67m |
| F-COMPLETE | F-BASE + DEMO-01…08 posted; DEMO-08 uncategorized, reconciliation unreconciled nếu scenario không chỉ định khác. Tiền 31,1m; assets 76,1m |
| F-Xnn | Reset F-COMPLETE rồi chỉ áp dụng thay đổi của SCN-Xnn; ngoại lệ X01/X03/X04/X05 nêu rõ bên dưới. Không tích lũy delta từ scenario trước |

Reset toàn bộ accounts/openings/events/movements/sources/cases/quotes/FX/settings/filters/drafts/operations/versions rồi load fixture chọn rõ. Cùng input cho cùng expected; không dùng output app làm oracle. Bước 3 triển khai fixture/script/ảnh và ghi observed versus expected. CSV ≤20 rows; mapping alias ngày→date, ref→reference, nợ→debit, có→credit, nội dung→description, tiền tệ→currency phải rõ.

## Baseline và oracle

DEMO-01…08 lần lượt ngày 02…09/10/2026 12:00 +07. Source/evidence hư cấu SRC-DEMO/EV-DEMO-xx, reference REF-DEMO-xx. Bảng là signed effects; event amount lưu magnitude dương. Transfer có cả hai phía được C xác nhận. Không fee trong baseline; opening không income; refund cùng kỳ.

| Event | Loại / liên kết / category | Bank Δ | Wallet Δ | Cash Δ | Thu–chi |
|---|---|---:|---:|---:|---|
| DEMO-01 | Income lương | +10.000.000 | 0 | 0 | Income 10m |
| DEMO-02 | Transfer bank→wallet | −2.000.000 | +2.000.000 | 0 | 0 |
| DEMO-03 | Transfer bank→cash, không phí | −1.000.000 | 0 | +1.000.000 | 0 |
| DEMO-04 | Expense ăn uống | 0 | 0 | −150.000 | Gross 150k |
| DEMO-05 | Expense ăn uống | 0 | −250.000 | 0 | Gross 250k |
| DEMO-06 | Expense mua hàng | −600.000 | 0 | 0 | Gross 600k |
| DEMO-07 | Refund liên kết DEMO-06 | +200.000 | 0 | 0 | Refund 200k |
| DEMO-08 | Expense chưa phân loại | −100.000 | 0 | 0 | Gross 100k |

| Oracle | Phép tính độc lập / expected VND |
|---|---|
| O-01 | Bank 20m+10m−2m−1m−600k+200k−100k = 26.500.000 |
| O-02 | Wallet 0+2m−250k = 1.750.000 |
| O-03 | Cash 2m+1m−150k = 2.850.000 |
| O-04 | Tổng tiền = O-01+02+03 = 31.100.000; opening 22.000.000 |
| O-05 | Income 10.000.000; gross 150k+250k+600k+100k = 1.100.000 |
| O-06 | Refund 200.000; net 1.100.000−200.000 = 900.000 |
| O-07 | Flow toàn bộ tiền = 31,1m−22m = +9.100.000; internal transfer delta 0 |
| O-08 | Stock 5m + gold 40m + tiền 31,1m = 76.100.000 |
| O-09 | Quote mới: stock 100×55k = 5,5m; gold 5×8,2m = 41m; assets 77.600.000. Tiền/thu–chi/flow giữ nguyên |
| O-10 | Bỏ wallet: bank+cash = 29.350.000; opening 22m; flow +7.350.000, gồm transfer 2m ra ngoài phạm vi |

Evidence thứ hai cho DEMO-06 không đổi oracle. Missing quote không thành 0; không tạo đường giá lịch sử từ một quote. Ký hiệu m=triệu VND, k=nghìn VND chỉ để đọc specification, UI phải hiển thị đơn vị rõ.

## Scenarios chính — planned cho bước 3

| ID / AC / UC | Input và sequence của actor C | Expected và nhánh bắt buộc | Rules / Data |
|---|---|---|---|
| SCN-SET-01 / AC-01 / UC-SET-01 | F-EMPTY chọn mốc/kỳ/VND, mở Tổng quan; F-BASE mở lại | Settings rõ; không opening income; lần sau mở thẳng, Review không chặn. Invalid/future/cancel không save | BR-01/03/04; DR-01/02/14 |
| SCN-BANK-01 / AC-02 / UC-BANK-01 | Sau SET tạo bank20m/wallet0; thiếu tên, opening âm, hủy | Hai loại/ID/ngày/nguồn, tiền subtotal20m; 0 known khác null; retry không thêm opening/account | BR-02/04/09/20; DR-02/07/08/15 |
| SCN-CASH-01 / AC-03 / UC-CASH-01 | Sau bank/wallet tạo cash2m; bỏ opening rồi bổ sung | Tổng tiền22m, tự khai báo, count unknown; missing không 0, cancel không mutation | BR-02/04/14; DR-02/12 |
| SCN-STOCK-01 / AC-04 / UC-STOCK-01 | F-BASE mở DEMO-A/DEMO/100/50k, cost null; thử market thiếu/lượng âm | Valuation5m, gain unknown, ngày lượng và giá riêng; market khác không áp quote | BR-02/15/18; DR-03/04/11 |
| SCN-GOLD-01 / AC-05 / UC-GOLD-01 | F-BASE gold9999/5chỉ/8m; đổi 0,5lượng; X09 quốc tế/FX | 40m ở hai đơn vị, nhãn loại/purity/nguồn/time; quốc tế có FX riêng, thiếu FX unknown | BR-02/15/16; DR-03/04/11 |
| SCN-IMPORT-01 / AC-06 / UC-IMPORT-01 | F-COMPLETE CSV R1 income100k ngày10/10 refEXTRA-01; R2 debit50k thiếu ngày; R3 candidate debit600k refREF-DEMO-06 ngày07/10. Map bank, preview/cancel rồi confirm chỉ R1 | Preview/cancel không tiền/case mới. Confirm bank26,6m/tiền31,2m/income10,1m/assets76,2m; R2/R3 vào Review không post. Retry job giữ số; resolve R3 delta0; commit lỗi không một nửa | BR-09/10/11; DR-06…10/13/15 |
| SCN-SOURCE-01 / AC-07 / UC-SOURCE-01 | F-COMPLETE notification duplicate06; quote stock55k; các fixture error/revoked/stale/disconnect/retry riêng | Notification không quantity; duplicate vào Review. Giá stock mới assets76,6m, tiền31,1m. Lỗi giữ giá/time cũ, không 0; dummy only | BR-09/18/22; DR-06/11/13 |
| SCN-MONEY-01 / AC-08 / UC-MONEY-01 | F-BASE chạy DEMO-01…08; thử amount≤0/missing/cancel; X04/X05 riêng | Cash sau03=3m, sau04=2,85m; O-01…08. Transfer không income/gross; refund ngày nhận riêng; invalid/cancel không delta | BR-02…09; DR-02/07/08/09/10/15 |
| SCN-CASH-02 / AC-09 / UC-CASH-02 | F-COMPLETE count2,8m cùng mốc; variance/cancel/defer; X07 resolve | Lệch−50k; trước confirm cash2,85m. Hủy resolution không đổi tiền; unknown adjustment khác expense | BR-14/21; DR-02/07/08/10/12 |
| SCN-HOLD-01 / AC-10 / UC-HOLD-01 | F-COMPLETE đổi giá55k+8,2m; reset rồi lượng110/date/reason; reset X08 purchase | Giá O-09; lượng riêng stock5,5m/assets76,6m, tiền31,1m/thu–chi giữ; purchase liên kết, không expense | BR-13/15…19; DR-04/05/07/08/11/14 |
| SCN-TXN-01 / AC-11 / UC-TXN-01 | F-COMPLETE filter bank/mua hàng/ngày/status; detail06; X02 pending; no-results | Fields/evidence/history/các trục status riêng; pending không posted total; empty khác lỗi nguồn | BR-03/05/12/19; DR-06…09/14/15 |
| SCN-TXN-02 / AC-12 / UC-TXN-02 | F-COMPLETE sửa draft70k→80k; override08→Khác; reset rồi sửa04 150k→120k | Draft không totals. Category gross1,1m giữ. Posted: cash2,88m/tiền31,13m/gross1,07m/refund200k/net870k/flow9,13m/assets76,13m; original/reversal/replacement; retry delta0 | BR-05/09/12/13; DR-06…10/15 |
| SCN-OVERVIEW-01 / AC-13 / UC-OVERVIEW-01 | F-BASE chạy toàn bộ DEMO, mở card/chart/table khi Review còn mở | O-01…08. Food400k; shopping gross600k/refund200k/net400k; uncategorized100k. Cùng snapshot, kỳ/đơn vị rõ | BR-03…08/17…19; DR-01/02/04/07/08/11/14 |
| SCN-DRILL-01 / AC-14 / UC-DRILL-01 | F-COMPLETE foodchart→list/Back, stock→holding/Back; toggle wallet; reset archive wallet | Đúng04/05 và holding; giữ context. O-10; assets bỏ wallet74,35m; history02/05 còn. Thiếu quote không tổng đầy đủ | BR-06/19/20; DR-02/04/07/11/14/15 |
| SCN-REVIEW-01 / AC-15 / UC-REVIEW-01 | F-COMPLETE evidence thứ hai06; từng loại case X02…07; preview/confirm/refuse/defer/cancel | Action theo loại; match delta0; resolved retry delta0; cùng tiền/ngày không auto gộp; không tự thêm phía nhận/expense | BR-05…14/21; DR-06…10/12/15 |
| SCN-REVIEW-02 / AC-16 / UC-REVIEW-02 | F-COMPLETE lượng30/09, giá29/10, source28/10, missing FX/sai product; update/refuse/defer | Ages/thiếu độc lập; stale quote giữ time; không verified ownership/accuracy%; đúng form/nguồn, resolve khi cause xử lý | BR-15/16/18/19/21/22; DR-03…06/10/11/14 |
| SCN-UX-01 / AC-17 / UC-UX-01 | Full fixture, 1440×900/390×844/360px, keyboard/Mask/dialog/errors/Back/table; 10 lượt đo local | Việt/focus/table/masking toàn bề mặt, không page overflow, lỗi có chữ. Mục tiêu local render≤1s; ghi máy/browser, **chưa đo** | BR-19/23/24; DR-14/15; NFR-02/03/09/11 |
| SCN-DEMO-01 / AC-18 / UC-DEMO-01 | F-BASE mutate/source error, Reset cancel/confirm; chọn F-COMPLETE/F-EMPTY rồi reset | F-BASE22m/67m; F-COMPLETE31,1m/76,1m theo lựa chọn. Reset mọi state/version/filter/draft; fake labels rõ, optional absent | BR-01/09/23/24; DR-01…15 |

## Nhánh bổ sung — reset độc lập, expected cụ thể

### SCN-X01 — Opening, original và reversal

Input: cash opening2m, posted chi150k, reversal150k, không replacement. Action xem history/balance. Expected cash2m, gross/net0, opening không income; original reversed vẫn có entries−150k cùng reversal+150k. Retry không lần2. Thêm replacement120k→cash1,88m/gross120k. BR-04/05/13; DR-02/07/08/09/14; REQ-TXN-02/SET-01. Chưa test ledger.

### SCN-X02 — Pending/draft và category độc lập

F-COMPLETE thêm pending expense70k bank và draft80k cash. Oracle unchanged, list/detail tách riêng. Phân loại DEMO-08 không đổi pending thành posted; uncategorized100k đã posted vẫn gross. Reject pending case không post event. BR-05/12/21; DR-07/08/10; REQ-TXN-01/REVIEW-01.

### SCN-X03 — Transfer một phía rồi ghép phía nhận

F-BASE: evidence bank out1m, biết cash đích nhưng chưa evidence nhận. Bank19m/cash2m/wallet0/tổng21m/flow−1m/income0/gross0; clearing+1m logic, case open. Không hiện cash3m. Sau C xác nhận cash received1m/date/evidence: cash3m/tổng22m/flow0, clearing giải quyết; không trừ bank lần2. Decline/defer không delta. BR-06/09/21; DR-02/07/08/09/10; REQ-MONEY-01/REVIEW-01.

### SCN-X04 — Transfer có phí

F-BASE chuyển bank→cash1m và fee10k bank, đủ hai phía. Bank18,99m/cash3m/tổng21,99m/income0/gross và net10k/flow−10k. Transfer1m không expense. Phí chưa rõ giữ fee pending, không ghép1,01m thành transfer. BR-06; DR-02/07/08; REQ-MONEY-01.

### SCN-X05 — Refund khác kỳ

F-COMPLETE **bỏ DEMO-07** tháng10, nhận refund200k ngày02/11 liên kết06; clock30/11 18:00. Tháng10: bank26,3m/tổng30,9m/income10m/gross1,1m/refund0/net1,1m/flow8,9m. Tháng11: opening tiền30,9m; cuối bank26,5m/tổng31,1m/income0/gross0/refund200k/net−200k/flow+200k. Không viết lại report10. Refund dùng ngày nhận, không ngày mua. BR-03/07; DR-07/09/14; REQ-MONEY-01/REVIEW-01/TRACK-01.

### SCN-X06 — Refund nhiều lần, chưa liên kết, nghi vượt

Nhánh A F-COMPLETE thêm linked refund100k: bank26,6m/tổng31,2m/gross1,1m/refund300k/net800k/flow9,2m/assets76,2m. Candidate400k làm tổng refund700k vượt mua600k: pending/case open, số chưa đổi, không auto cap.

Nhánh B reset F-COMPLETE **bỏ07**, receipt200k type unresolved_receipt: bank26,5m/tổng31,1m/income10m/gross1,1m/refund0/net1,1m/flow9,1m. Resolve link06→refund200k/net900k, bank unchanged. Reject đề xuất link giữ loại chưa rõ/case history, không tự gán income. BR-07/08/21; DR-07/08/09/10/14; REQ-MONEY-01/REVIEW-01.

### SCN-X07 — Cash variance: adjustment hoặc chi quên

F-COMPLETE count2,8m versus calculated2,85m: −50k; chưa confirm không money delta. Nhánh A confirm adjustment_unknown−50k có reason: cash2,8m/tổng31,05m/assets76,05m/income10m/gross1,1m/refund200k/net900k/flow9,05m. Nhánh B reset, nhập chi quên50k có evidence: tiền/assets/flow như A nhưng gross1,15m/net950k. Không áp dụng cả hai. Mốc/type khác không đối chiếu. BR-14/21; DR-02/07/08/10/12; REQ-CASH-02.

### SCN-X08 — Mua mới liên kết tiền đầu tư

F-COMPLETE giá50k; mua10share500k từ bank/date/evidence. Bank26m/tổng tiền30,6m/stock110share5,5m/gold40m/assets76,1m/income10m/gross1,1m/refund200k/net900k/flow8,6m. Không expense sinh hoạt500k. Fail/cancel không ghi nửa cash/holding. BR-15/17; DR-04/05/07/08/09/11/14; REQ-HOLD-01/MONEY-01.

### SCN-X09 — Quote/FX thiếu, cũ, sai unit/purity/market

F-COMPLETE gold5chỉ. VND/chỉ8m ↔ VND/lượng80m; hoặc USD/lượng3200×FX25000→40m với nhãn quốc tế. Quote phù hợp9999 không nhân0,9999 lần2. Unit không mapping/purity khác bị từ chối. FX hoặc gold quote missing→gold unknown, known subtotal36,1m/full total null, tiền31,1m; không gold0. Quote DEMO-A/marketOTHER không áp dụng. Stale quote29/10 17:00 giữ40m có nhãn/time cũ. Đúng24h/30d/48h chưa stale, vượt1giây stale; FX demo24h riêng. Lượng30/09/source28/10 cũ độc lập. BR-02/15/16/18/19/22; DR-03/04/06/11/14; REQ-GOLD-01/HOLD-01/REVIEW-02.

Rounding fixture riêng với unit giả: quantity0,3×quote1,5=0,45 VND→0 VND sau round-half-up; raw valuation vẫn known0,45, không missing. Raw0,5 VND→1 VND. Round từng holding rồi cộng; không làm tròn quantity/quote trước nhân. Không trộn fixture này vào baseline gold40m.

### SCN-X10 — Revision nguồn, override và CSV ambiguity

F-COMPLETE override08→Khác100k. Reimport cùng ref08/parser revision mới đề xuất Ăn uống: giữ override và money oracle. Revision đề xuất amount120k: needs_review, chưa post20k trước preview/confirm. Nếu confirmed reversal/replacement: bank26,48m/tổng31,08m/gross1,12m/refund200k/net920k/flow9,08m/assets76,08m, override Khác còn. CSV thiếu date/31-02/hai cột dương/"150,000" sai integer profile→blocked. Reference thiếu hợp lệ nhưng không suy dedupe. BR-09/10/12/13/21; DR-06…10/13; REQ-INPUT-01/TXN-02.

### SCN-X11 — Cancel, timeout sau confirm, retry và conflict

F-COMPLETE sửa cash04→120k, expectedVersion1/keyK1. Cancel trước confirm không delta. Mô phỏng commit thành công nhưng mất response: trạng thái chưa rõ, retry K1 cùng payload→cash2,88m và totals SCN-TXN-02, không effect lần2. Payload130k cùngK1→conflict, no delta. Case version1 trong khi client khác version2 resolved→conflict, reload/re-preview, không resolve lần2. Double confirm chặn khi đang xử lý, không success giả. CSV selected2 valid rows fail commit→cả hai không post. Denied không change. **Chưa backend fault injection.** BR-09/11/13/21; DR-07…10/13/15; NFR-04; REQ-INPUT-01/MONEY-01/TXN-02/REVIEW-01.

### SCN-X12 — Mất quyền và ownership

F-COMPLETE source permission_revoked→refresh blocked, quote cũ giữ label/time; reconnect dummy mới cho refresh. Disconnect giữ history. Reference workspace B đưa vào account/event/evidence/holding/report/case A→denied, không detail/mutation. M1 chỉ state mô phỏng, **không chứng minh isolation/anti-Ops**. M3 cần direct API và attacks DB/gateway/queue/log/backup/client/auth/recovery theo OD-07; chưa chạy bước2. BR-01/22; DR-01…15; NFR-07/08; REQ-INPUT-02/REVIEW-02.

## Chuỗi xuyên chức năng và bằng chứng tương lai

C: SET/BANK/CASH/STOCK/GOLD → MONEY/IMPORT/SOURCE → OVERVIEW → DRILL/TXN → TXN-02 hoặc REVIEW → OVERVIEW → RESET. Thiếu/cũ không chặn phần đủ; permission/conflict không bỏ validation. Mỗi AC cần success và lỗi phù hợp, ảnh/log đã lọc và observed versus expected ở bước3. Các nhánh delta phải đối chiếu account/total/income/gross/refund/net/flow/assets/history, không chỉ một card.

Gate bước2 kiểm tra specification/expected/links. Gate M1 cần prototype thực thi và UX evidence. Chưa có research/provider verification/security PoC/application test trong tài liệu này.
