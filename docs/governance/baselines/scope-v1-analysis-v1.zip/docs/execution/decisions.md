# FinWeave — Quyết định và giả định

Ngày: 05/10/2026. Version 1.1, scope-v1 → analysis-v1. Phân biệt quyết định theo nhiệm vụ, lựa chọn phân tích và vấn đề còn mở. Không có phỏng vấn hoặc xác minh API mới trong lần này. Owner theo dõi: Agent; PO reviewer/approver pending external review.

## Quyết định baseline

| ID | Quyết định / trạng thái | Căn cứ | Tác động |
|---|---|---|---|
| D-01 | M1, chỉ bước 1 ở nhiệm vụ cũ — superseded **chỉ phần STEP_RANGE** bởi D-12 | User và Playbook mục 4 | M1/synthetic/scope-v1 giữ nguyên; nhiệm vụ mới thực hiện bước 2 rồi dừng |
| D-02 | Bốn nhóm × năm chức năng, web responsive tiếng Việt, synthetic — chốt | User | Không collector thật, không sản phẩm Android thứ hai |
| D-03 | Budget/Goals/Alerts/Assistant ngoài bàn giao — chốt | User | Không tab/card/chat/inbox của bốn module; status/badge Review vẫn lõi |
| D-04 | Prototype Ideas ánh xạ theo mức thực thi Playbook — chốt cách diễn giải | Playbook mục 1, 15 và Human Setup | Backend ledger/job/security thật thuộc M3; M1 chứng minh hành vi và nguồn số giả |
| D-05 | Một workspace demo, VND, +07:00, mốc theo dõi; không auth thật — baseline thiết kế | User synthetic; Ideas 2–3; giả định A-01 | Onboarding không cần signup; currency khác chỉ trong fixture quote FX, không đa tiền tệ tài khoản |
| D-06 | Tiền khác tài sản; dùng “tài sản đang theo dõi”; opening/transfer/refund/reversal và pending đúng nguồn — giữ yêu cầu | Ideas 1.10–1.12, 8–9; Playbook 13 | Oracle/visual phải nhất quán; giá tăng không thành income |
| D-07 | M1 category hệ thống + override từng mục; holdings có lịch sử khai báo/điều chỉnh; hoãn rules/batch/trade engine/export | Chọn mức tối thiểu trong phạm vi user và Ideas | Không tự mang toàn module prototype vào mốc; có ví dụ mua đủ căn cứ nhưng không đặt lệnh/hiệu quả đầu tư đầy đủ |
| D-08 | Web prototype chạy local là hướng chính cho bước 3; chưa chọn stack | User responsive web; Human Prompt 3 | Đủ thao tác/reset; chọn công cụ khi xây, không cài thư viện bước 1 |
| D-09 | Security/Ops yêu cầu vẫn bắt buộc trước dữ liệu thật; chưa làm PoC | Ideas 15–16; Playbook 2.4 | Ghi DEP-04, không tự hạ bảo đảm; PoC không là gate prototype UI |
| D-10 | Mở rộng hồ sơ bước 1 đủ 11 artefact chuyên nghiệp — chốt theo yêu cầu bổ sung | User yêu cầu Vision/Problem/Value/Charter/Scope/Feasibility/Options/Cost/Assumptions-Constraints/Risks/Roadmap | Tạo bộ Markdown và mục lục; giữ backlog/execution, không mở rộng tính năng hoặc sửa ba nguồn |
| D-11 | Cost model dùng effort low/base/high và biến đơn giá chưa chốt — ước lượng lập kế hoạch | Chưa có budget/time log/báo giá/capacity | Không hẹn ngày/tổng VND; cập nhật sau rules và vòng UX đầu; không mua dịch vụ |

## Giả định nghiên cứu chưa kiểm chứng

| ID | Giả định | Tác động / cần kiểm chứng |
|---|---|---|
| A-01 | User đầu là cá nhân tự quản lý nhiều tài khoản tiền và khai báo cổ phiếu/vàng | Form và ngôn ngữ dành cho chủ dữ liệu; cần phỏng vấn/thử tác vụ |
| A-02 | Ba câu hỏi ưu tiên: tiền ở đâu, chi vào gì, dữ liệu nào cần kiểm tra | Hierarchy Tổng quan; chưa có bằng chứng tần suất/giá trị |
| A-03 | Dùng mobile nhập nhanh và desktop kiểm tra chi tiết | Viewport/UX đề xuất; cần kiểm chứng thiết bị thật |
| A-04 | 5 người thử, ≥4/5 hoàn thành là mục tiêu khả thi cho đánh giá nhỏ | Đề xuất đo, chưa tuyển người, chưa có tỷ lệ thực; không là khảo sát đại diện |

## Quyết định còn mở có tác động thực tế

Các mặc định dưới đây cho phép chuẩn bị bước 2 mà không mở rộng scope. Chủ sản phẩm có thể đổi trước khi thiết kế; mọi thay đổi cập nhật scope/version/scenarios, không ghi thành đã được user duyệt.

| ID / hạn cần chốt | Vấn đề còn mở | Mặc định đề xuất / lựa chọn | Tác động nếu đổi / cách kiểm chứng |
|---|---|---|---|
| OD-01 / trước đánh giá UX | User đầu và người tham gia có đủ bốn nhóm? Có rubric yêu cầu bổ sung? | A-01…03, chưa có người tham gia/rubric; chỉ tự walkthrough nếu không có | Có thể đổi ưu tiên/nhãn và kịch bản; phỏng vấn/test thật khi có người, không tự thêm Budget |
| OD-02 / bước 2 | Kỳ demo, timestamp và khi nào nguồn/lượng/giá được coi cũ | Kỳ 01–31/10/2026, thời điểm mô phỏng 31/10/2026 18:00 +07; giá quá 24h, lượng quá 30 ngày, nguồn quá 48h là fixture cũ | Ngưỡng chỉ phục vụ demo, không cam kết SLA nguồn/chu kỳ thị trường; rules cần nêu quote lịch sử/phiên giao dịch; đổi thì sửa fixture và nhãn |
| OD-03 / bước 2 | CSV và số mẫu dùng trong import | Một schema sao kê demo: ngày, reference, ghi nợ, ghi có, nội dung, VND; biến thể tên cột để thử mapping; không parser bank thật | Khác định dạng làm đổi validation/preview; chuẩn bị fixture hợp lệ/lỗi/trùng, không đưa file thật |
| OD-04 / bước 2 | Quote vàng/FX và phạm vi mua/bán tối thiểu | Quote giả VND/chỉ tương thích vàng nhẫn demo 9999; scenario quốc tế USD + FX giả riêng; 1 lượng=10 chỉ; nhánh sai đơn vị/purity/thiếu FX. Lượng thay đổi bằng form có ngày/lý do, một ví dụ mua gắn dòng tiền | Nếu chọn giá mua vào/thanh lý cần nhãn khác; bước 2 chốt quy đổi/rounding và tách price/quantity. Không thêm trade lifecycle đầy đủ |
| OD-05 / trước nguồn thật | Ngân hàng/ví hỗ trợ đầu, kênh thu thập và provider cổ phiếu/key/license/quota | Chưa chọn; SSI chỉ ứng viên trong Ideas | Quyết định thay schema/adapter/quyền; phải thử mẫu có quyền và terms thời điểm tích hợp; không cản M1 |
| OD-06 / trước định giá thật | Nguồn vàng nội địa/quốc tế, FX, loại quote và lịch refresh | Chưa chọn; thông tin thử Gold API trong Ideas không phải kiểm chứng lần này | License/unit/time/buy-sell tác động giá trị báo cáo; phải xác minh trước gọi nguồn thật |
| OD-07 / trước contract transport M2 và dữ liệu thật M3 | Protected boundary/provider, key/code approval độc lập Ops, user/device/recovery, ngân sách | Chưa chọn, chưa PoC; không hạ yêu cầu chống Ops | Có thể đổi transport và runtime; FUT-02/DEP-04 cần PoC/chi phí/gate. Chưa đạt thì chỉ synthetic integration |

Hiện không có quyết định thiếu làm chặn hoàn thành bước 1. Stack M1 là lựa chọn kỹ thuật thông thường ở bước 3; public deployment, ngân sách mới và dữ liệu thật chưa được cấp quyền. Không coi thời gian trôi qua là phê duyệt các lựa chọn còn mở.

## Quyết định và giả định phân tích bước 2

Ngày áp dụng 05/10/2026. D-12 là quyền user cấp; D-13…18 là **giả định phân tích chưa PO phê duyệt**, AG chịu trách nhiệm consistency, PO review trước đổi baseline. Không thay yêu cầu nguồn để khớp số. Nguồn trực tiếp: Playbook §3.5/5/13, scope-v1/18 REQ–AC và nhiệm vụ chat.

| ID / trạng thái | Lựa chọn / căn cứ | Alternatives và tác động | Artefact/rule bị ảnh hưởng |
|---|---|---|---|
| D-12 / chốt theo nhiệm vụ | Hoàn thiện quản trị bước 1 trước phân tích, làm đủ 10 artefact bước 2, đánh giá gate rồi dừng. Register đăng ký owner/version/source/trace; vẫn M1 preparatory, không bước 3 | Mô tả cũ chỉ UC/rules/dictionary thiếu Playbook; superseded tại plan/progress/backlog/Scope§9/Charter/Roadmap. Không thêm tính năng | GOV-REG-001; EXE; PRD/REQ/DAT gói 2; D-01 partial superseded |
| D-13 / giả định OD-02/04 | Kỳ10/2026 half-open +07, clock31/10 18:00. Tuổi strict >24h giá/FX, >30d lượng, >48h lastSuccess nguồn; timestamp unknown/future không giả fresh. VND mutation nguyên, quantity/quote/FX decimal string; valuation round-half-up từng holding tới1VND rồi cộng. 1lượng=10chỉ; quote9999 compatible không purity-adjust lần2; USD/lượng3200×FX25000 fixture quốc tế riêng | Theo phiên thị trường/FX source policy là lựa chọn thật chưa chốt; per-total rounding có thể khác1VND, chưa chọn. FX24h bổ sung là demo assumption, không market/SLA. Quote baseline31/10 17:00, lượng01/10 18:00 cho ngưỡng đúng30d; không giá lịch sử opening | BR-02/03/16/18; DR-01/04/11/14; SCN-X05/X09; OD-02/04 vẫn assumption |
| D-14 / giả định OD-03 | CSV demo UTF-8 date/reference/debit/credit/description/currency, ISO date-only precision giữ date, VND integer profile, exactly one positive direction; reference optional không giả ref; ≤20rows. Commit atomic selected valid subset, excluded Review chỉ publish sau confirm; cancel preview không money/case mutation. Same key/payload retry; changed payload conflict; expectedVersion re-preview | Thực hiện full-file hoặc chunking/locale-specific bank parser là phương án sau; không tuyên bố prototype hỗ trợ bank thật. Cancel sau commit không rollback, cần adjustment. Category missing không blocked | BR-09…13/21; DR-06/13/15; UC-IMPORT/MONEY/TXN/REVIEW; SCN-X10/X11 |
| D-15 / giả định xử lý cash phù hợp nguồn | Count là observation, variance không posting. Unknown adjustment có reason+preview+confirm tác động cash/flow, **không sinh hoạt income/expense**. Nếu evidence chi quên thì expense riêng, không đồng thời adjustment | Auto expense để ép khớp bị nguồn cấm. Khi tìm nguyên nhân sau, reclassify/adjust có history, không overwrite count/event. Cancel resolution giữ money, observation đã lưu có thể giữ | BR-14; DR-07/08/12; UC-CASH-02; SCN-X07 |
| D-16 / giả định receipt/refund phù hợp nguồn | Receipt đủ money fields chưa rõ loại có thể posted vào unresolved_receipt/clearing, tiền nhận phản ánh nhưng chưa income/refund. Resolve liên kết refund reclassify không cash lần2. Candidate refund vượt gốc giữ pending/case, không auto cap hoặc auto income | Giữ toàn bộ receipt pending sẽ làm cash khác scenario; phân tích chọn clearing để phản ánh money known/type unknown. Alternative chỉ đổi qua decision/version+SCN. Cross-period refund giảm chi kỳ nhận là **giữ nguồn**, không lựa chọn mở | BR-07/08/21; DR-07/08/10/14; UC-MONEY/REVIEW; SCN-X05/X06 |
| D-17 / giả định scope/archive phù hợp nguồn | Archive ngăn mutations mới, mặc định bỏ scope hiện tại, giữ history/include-archive reporting. Snapshot missing component → full total null + known subtotal/list missing; không tỷ trọng tổng đầy đủ. Version changed phải refresh/re-preview | Archive vẫn in-scope là alternative chưa chọn; nguồn yêu cầu không delete history vẫn giữ ở cả hai. Client tự cộng tổng khác Engine không được chọn. Toggle scope không ledger change | BR-19/20; DR-02/14; UC-OVERVIEW/DRILL; SCN-DRILL/X09 |
| D-18 / giả định UX/demo target | Đủ 18 UC gồm UC-UX-01 explicit, giữ UC/SCN IDs cũ; bổ sung 12 SCN-Xnn/24 BR/15 DR/11 NFR. F-BASE default Reset, F-COMPLETE lựa chọn rõ. Local demo≤20rows proposed≤1s rendering/filter/preview, 10 lượt đo sau warm-up ghi máy/browser/max; chưa đo | Bỏ hiệu năng threshold chỉ định qualitative là alternative; PO review trước UX validation. M3 SLO/capacity cần benchmark riêng, không kế thừa 1s local. Chưa chọn storage/stack bước 3 | NFR-02/03/06/09/11; BR-23/24; DR-15; UC-UX/DEMO; SCN-UX/DEMO |

OD-02/03/04 **được áp dụng làm giả định**, không closed/approved; owner AG cập nhật rules/data/scenarios/RTM khi PO thay policy. Không phát hiện mâu thuẫn với 18 AC/oracle cần thay scope-v1; đã giải quyết thiếu mô tả gói bước 2 bằng D-12. Đồng thời làm rõ receipt/refund, unknown adjustment, missing totals và archive bằng D-15…17 thay vì để diễn giải ngầm. OD-01/A-01…04 và OD-05…07 vẫn open; không giả nghiên cứu/provider/PoC. Security requirement D-09 không superseded.

Gate/self-review bước 2: [EVD-S2-001](evidence/step-2-review.md). Artefact in-review, analysis-v1 là baseline làm việc; formal sign-off vẫn pending external review. [Register](../governance/artifact-register.md) giữ version và owner; không có hai bản RTM/dictionary nguồn sự thật cùng hiệu lực.
