# FinWeave — Kế hoạch execution

Ngày: 05/10/2026. Baseline `scope-v1`.

## Nhiệm vụ và đầu vào

| Trường | Giá trị |
|---|---|
| PROJECT_ROOT | `C:\Users\Lenovo\Downloads\Kì 1 năm 3\Information Systems Modeling and Design` |
| IDEA_SOURCE | `FinWeave_Ideas.md` ở root |
| TARGET_LEVEL | M1 — Prototype |
| STEP_RANGE được giao | Hoàn thiện quản trị bước 1 → thực hiện bước 2 → đánh giá gate bước 2 rồi dừng |
| FEATURE_SCOPE | Ngân hàng/ví, tiền mặt, cổ phiếu, vàng; thiết lập, thu thập/cập nhật, quản lý giao dịch, theo dõi, Review |
| OPTIONAL_FEATURES | Budget/Goals/Alerts/Assistant `out-of-scope` lần này |
| DATA_MODE / PLATFORM | Synthetic; responsive web tiếng Việt; demo local |
| AUTHORIZED_ACTIONS lần này | Đọc workspace, tạo/sửa tài liệu và kiểm tra local bước 2; không thực hiện bước 3 |
| KNOWN_CONSTRAINTS | Không dữ liệu thật, billing/trả phí hoặc public deployment; chưa có deadline/ngân sách tiền cụ thể; không tự thêm module |
| APP_DIR / stack / package manager | Chưa có ứng dụng/chưa chọn; không scaffold ở bước 1 |

## Thứ tự và điều kiện chuyển bước

1. BL-01: đọc ba nguồn, kiểm kê và quy định áp dụng → bộ hồ sơ bước 1 mở rộng theo yêu cầu mới (Vision, Problem, Value, Charter, Scope, Feasibility, Options, Cost, Assumptions/Constraints, Risks, Roadmap), backlog → decisions/traceability → kiểm tra tài liệu. Gate: đủ artefact, mỗi REQ lõi có benefit/mức/AC, các phần chưa chọn riêng, cost/risk/giả định có nhãn và đủ đầu vào bước 2.
2. Trước phân tích: đăng ký bộ bước 1 trong [Artifact Register](../governance/artifact-register.md), đồng bộ plan/progress/backlog và mô tả bước 2. Sau đó BL-02…06 tạo đủ **Stakeholder Needs, Context Model, Operational Scenarios, PRD, SRS (FR + NFR), Use Cases, Business Rules Catalogue, Data Requirements, Glossary và RTM** theo Playbook §3.5/5. Dùng scope-v1/18 REQ–AC/oracle; OD-02…04 là giả định có owner AG, không phê duyệt ngầm.
3. Khi được giao bước 3: BL-07…11 → UX/prototype web tương tác local → walkthrough desktop/mobile/keyboard, sửa lỗi → evidence/demo guide → đánh giá M1 đúng scope.
4. M2/M3 chỉ là hướng tiếp nối FUT-01…04. Nguồn thật/transport/security có phụ thuộc riêng; không đưa thành điều kiện gate M1 và không tự triển khai trong nhiệm vụ này.

Ưu tiên tác vụ của user và tính nhất quán dữ liệu. Dữ liệu hợp lệ hiện ngay trong Tổng quan; Review không là cửa bắt buộc trước dashboard. Không yêu cầu backend để chạy tác vụ mô phỏng.

Hồ sơ sản phẩm: [mục lục đầy đủ](../product/README.md), [scope](../product/scope.md), [backlog](../product/backlog.md). Execution: [decisions](decisions.md), [traceability](traceability.md), [progress](progress.md). Evidence tài liệu bước 1 nằm trong `evidence/step-1-review.md`; evidence prototype sẽ tạo ở bước 3.

## DoR/DoD bước 2 — version 1.1, scope-v1

DoR: scope-v1/18 REQ–AC/oracle có sẵn; user cho phép OD-02/03/04, AG chịu trách nhiệm ghi giả định; register đã đăng ký bước 1. Không có dependency chặn phân tích synthetic.

DoD: đủ 10 artefact, mỗi UC đủ actor/trigger/precondition/main/alternative-error/rules/data/postcondition; mỗi FR/AC có UC/SCN/rule/data; NFR có mục tiêu/đánh giá/mức rõ; rules có expected chuyển thành test; các trục trạng thái tách riêng; links/IDs/bao phủ/oracle được kiểm tra và lưu evidence. Gate chỉ đánh giá chất lượng tài liệu bước 2; ngoại review pending, chưa M1. Dừng sau gate, không scaffold app, không user research/provider verification/security PoC giả.
