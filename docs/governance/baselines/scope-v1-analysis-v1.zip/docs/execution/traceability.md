# FinWeave — Requirements Traceability Matrix

ID REQ-RTM-001 · v1.0 `analysis-v1` trên `scope-v1` · 05/10/2026 · in-review, pending external review. Owner/self-review Agent; approver PO chưa sign-off. Thay nội dung RTM bước1 cùng đường dẫn; mapping UC/SCN nay đã đặc tả, screen/API/test vẫn **planned**, không contract hay implementation. 18 REQ và 18 AC giữ nguyên nguồn [Scope](../product/scope.md).

Nguồn sự thật: [Needs](../product/stakeholder-needs.md), [Context](../requirements/context-model.md), [PRD](../product/prd.md), [SRS FR/NFR](../requirements/srs.md), [UC](../product/use-cases.md), [Scenarios](../product/operational-scenarios.md), [Rules](../product/business-rules.md), [Data](../data/data-requirements.md), [Glossary](../requirements/glossary.md). ID rút gọn trong cột Rules/Data là thành phần của prefix đầu tiên (BR-02/04 = BR-02, BR-04); dấu … là dải inclusive. UC và SCN chính giữ ID dự kiến từ bước1; UC-UX-01 bổ sung cho REQ-UX-01 vốn xuyên UC, không thêm FR.

## RTM chức năng: nguồn → hành vi → tiêu chí → căn cứ

| Requirement / Ideas § / Need | UC → màn hình dự kiến | SCN chính / nhánh → AC / oracle | Rules | Data | Logical API M2 dự kiến | Backlog / trạng thái / evidence |
|---|---|---|---|---|---|---|
| REQ-SET-01 / 2–3 / SN-01 | UC-SET-01 → Thiết lập/demo | SCN-SET-01, SCN-X01 → AC-01 / O-04 opening | BR-01/03/04/19/24 | DR-01/02/14/15 | getWorkspace/updateTrackingSettings | BL-02/06/08; planned; EVD-S2-001 documents only |
| REQ-BANK-01 / 3 / SN-01 | UC-BANK-01 → Tài khoản tiền | SCN-BANK-01 → AC-02 / O-01/02 opening | BR-01/02/04/09/20 | DR-02/07/08/14/15 | createAccount/listAccounts | BL-02/08; planned; EVD-S2-001 documents only |
| REQ-CASH-01 / 1.2.B,3 / SN-01/02 | UC-CASH-01 → Tạo ví cash | SCN-CASH-01 → AC-03 / O-03 opening | BR-01/02/04/14 | DR-02/07/08/12/15 | createAccount | BL-02/08; planned; EVD-S2-001 documents only |
| REQ-STOCK-01 / 1.2.C,3 / SN-03 | UC-STOCK-01 → Cổ phiếu | SCN-STOCK-01, SCN-X09 → AC-04 / O-08 stock | BR-02/15/18/19/22 | DR-03/04/05/11/14 | createHolding/listHoldings | BL-02/08; planned; EVD-S2-001 documents only |
| REQ-GOLD-01 / 1.2.D,3 / SN-03 | UC-GOLD-01 → Vàng | SCN-GOLD-01, SCN-X09 → AC-05 / O-08 gold | BR-02/15/16/18/19 | DR-03/04/05/10/11/14 | createHolding/listPriceQuotes | BL-02/08; planned; EVD-S2-001 documents only |
| REQ-INPUT-01 / 4 / SN-05 | UC-IMPORT-01 → Nguồn/Import | SCN-IMPORT-01, SCN-X10, SCN-X11 → AC-06 / O-01…08 + branch delta | BR-01/02/03/09/10/11/12/21 | DR-06…10/13/14/15 | previewImport/confirmImport/getImportJob | BL-03/08; planned; EVD-S2-001 documents only |
| REQ-INPUT-02 / 1.1–1.7,4 / SN-03/05 | UC-SOURCE-01 → Nguồn | SCN-SOURCE-01, SCN-X09, SCN-X12 → AC-07 / O-08/09 price | BR-09/10/18/19/22 | DR-06/07/09/10/11/13/14/15 | listSources/refreshSource/disconnectSource | BL-03/08; planned; EVD-S2-001 documents only |
| REQ-MONEY-01 / 1.10–1.12,5–6 / SN-02/05 | UC-MONEY-01 → Thu–chi/Chuyển/Refund | SCN-MONEY-01, SCN-X03…06, SCN-X11 → AC-08 / O-01…08 | BR-01…09/12/13/19 | DR-02/07/08/09/10/14/15 | createEvent/createTransfer/linkRefund | BL-03/08; planned; EVD-S2-001 documents only |
| REQ-CASH-02 / 1.2.B,6,14 / SN-02 | UC-CASH-02 → Kiểm đếm/Review | SCN-CASH-02, SCN-X07 → AC-09 / O-03 + variance | BR-02/04/14/21 | DR-02/07/08/09/10/12/14/15 | previewCashCount/resolveReviewCase | BL-03/08; planned; EVD-S2-001 documents only |
| REQ-HOLD-01 / 1.1–1.2,3,19 / SN-03 | UC-HOLD-01 → Lượng/Giá/Lịch sử | SCN-HOLD-01, SCN-X08, SCN-X09 → AC-10 / O-08/09 | BR-02/13/15…19 | DR-04/05/07/08/09/11/14/15 | updateHolding/listHoldingMovements/refreshQuotes | BL-03/08; planned; EVD-S2-001 documents only |
| REQ-TXN-01 / 5 / SN-04 | UC-TXN-01 → Giao dịch/Chi tiết | SCN-TXN-01, SCN-X02 → AC-11 / O-05/06 posted vs pending | BR-03/05/12/19/20 | DR-06…09/14/15 | listTransactions/getTransaction | BL-04/09; planned; EVD-S2-001 documents only |
| REQ-TXN-02 / 5,7 / SN-04 | UC-TXN-02 → Sửa/Category/Điều chỉnh | SCN-TXN-02, SCN-X01, SCN-X10, SCN-X11 → AC-12 / O-03/05 correction | BR-05/09/12/13/19 | DR-06…10/14/15 | updateDraft/updateCategory/adjustEvent | BL-04/09; planned; EVD-S2-001 documents only |
| REQ-TRACK-01 / 8–9 / SN-01/03/04 | UC-OVERVIEW-01 → Tổng quan | SCN-OVERVIEW-01, SCN-X05, SCN-X09 → AC-13 / O-01…09 | BR-03…08/17/18/19/23 | DR-01/02/04/07/08/11/14/15 | getOverview/getSpendingReport/getPortfolio | BL-04/09; planned; EVD-S2-001 documents only |
| REQ-TRACK-02 / 3,8–9,18 / SN-01/04 | UC-DRILL-01 → Visual→Giao dịch/Tài sản | SCN-DRILL-01, SCN-X09 → AC-14 / O-10 | BR-01/06/19/20 | DR-02/04/07/11/14/15 | listTransactions/listHoldings/updateAccountScope | BL-04/09; planned; EVD-S2-001 documents only |
| REQ-REVIEW-01 / 6,14 / SN-05 | UC-REVIEW-01 → Kiểm tra dữ liệu tiền | SCN-REVIEW-01, SCN-X02…07, SCN-X11 → AC-15 / O-01…08 + branch | BR-05…14/21 | DR-06…10/12/14/15 | listReviewCases/previewResolution/resolveReviewCase | BL-04/09; planned; EVD-S2-001 documents only |
| REQ-REVIEW-02 / 1.4,14 / SN-03/05 | UC-REVIEW-02 → Chất lượng tài sản/nguồn | SCN-REVIEW-02, SCN-X09, SCN-X12 → AC-16 / O-08 missing | BR-15/16/18/19/21/22 | DR-03…06/10/11/14/15 | listReviewCases/updateHolding/refreshSource | BL-04/09; planned; EVD-S2-001 documents only |
| REQ-UX-01 / 9,18 / SN-06 | UC-UX-01 + xuyên UC → tất cả màn | SCN-UX-01 → AC-17 / labels/table/mask | BR-19/23/24 | DR-14/15 | Không API riêng M1 | BL-07/10; planned; EVD-S2-001 documents only |
| REQ-DEMO-01 / Playbook2.3,6,13 / SN-06 | UC-DEMO-01 → Mở/Reset demo | SCN-DEMO-01 → AC-18 / O-01…10 sau đúng fixture | BR-01/09/23/24 | DR-01…15 | resetDemo chỉ mock, không real-data reset | BL-06/08/10; planned; EVD-S2-001 documents only |

Oracle cho branch cụ thể có ở Operational Scenarios; cột O chỉ liên kết baseline/khái niệm, không dùng expected baseline cho mọi branch. Test M1 tương lai theo SCN/AC; chưa có automated test IDs/app hoặc screen artefact. API chỉ logical operation dự kiến M2, chưa đặc tả transport/auth/errors; bước4 bổ sung contract IDs/path, bước6 test IDs/results, bước3 screen/ảnh/walkthrough. Evidence EVD-S2-001 xác minh hồ sơ, **không** verified các FR.

## RTM NFR, rủi ro và dependency

| NFR | UC/SCN / rule/data | Requirement hoặc stakeholder liên quan | Kiểm chứng theo mức / trạng thái |
|---|---|---|---|
| NFR-01 | UC-MONEY-01/OVERVIEW-01/HOLD-01/TXN-02; SCN-OVERVIEW-01, SCN-X01…10; BR-02…19, DR-14 | SN-01…05, REQ-MONEY-01/TRACK-01/HOLD-01/TXN-02; R-03/05 | Expected độc lập rà tài liệu EVD-S2-001; M1/M2/M3 correctness tests planned |
| NFR-02 | UC-UX-01; SCN-UX-01; BR-23, DR-15 | REQ-UX-01, SN-06 | Accessibility walkthrough bước3/audit bước6 planned |
| NFR-03 | UC-UX-01; SCN-UX-01; BR-02/03/23, DR-01/15 | REQ-UX-01, A-03 | 3 viewport/localization bước3 planned |
| NFR-04 | UC-IMPORT-01/MONEY-01/TXN-02/REVIEW-01; SCN-X11; BR-09/11/13/21, DR-15 | REQ-INPUT-01/MONEY-01/TXN-02/REVIEW-01 | M1 state; M2 mock errors; M3 fault/concurrency planned |
| NFR-05 | Xuyên UC; SCN-DRILL-01/REVIEW-01; BR-18…24, DR-09/14 | SN-07, toàn bộ18 FR | ID/link/bao phủ rà EVD-S2-001; provenance trong app planned |
| NFR-06 | UC-DEMO-01; SCN-DEMO-01; BR-24, DR-15 | REQ-DEMO-01; SN-06 | Fixture specification có; app reset/replay bước3/6 planned |
| NFR-07 | UC-SOURCE-01/UX-01; SCN-X12; BR-01/22/23/24, DR-06/15 | REQ-INPUT-02/UX-01, SN-08, D-09, OD-07 | Synthetic/no secret policy rà; transport bước4, thực thi bước7/8 pending |
| NFR-08 | SCN-X12 (demo only); BR-01, DR-01…15 | SN-08, Ideas15–16, DEP-04/FUT-02, OD-07 | Anti-Ops/ownership **unverified**; cần PoC và direct security evidence M3 |
| NFR-09 | Xuyên UC;18 SCN chính; BR-23, DR-15 | REQ-UX-01, SN-01…06, OD-01/A-04 | Agent walkthrough và user test (nếu có) bước3 planned; chưa nghiên cứu |
| NFR-10 | UC-SOURCE-01/GOLD-01/REVIEW-02; SCN-X09/12; BR-15…22, DR-11 | REQ-INPUT-02/GOLD-01/REVIEW-02; OD-02/04/05/06 | Demo policy specified; provider/license verification chưa làm |
| NFR-11 | UC-UX-01/IMPORT-01/TXN-01; SCN-UX-01/IMPORT-01/TXN-01; DR-13/15 | SN-06, D-18 | Local ≤1s là target giả định chưa đo; production benchmark/SLO deferred |

## Quản trị và phiên bản

BL-05/06 nối các FR với BR/Data/Glossary/SRS/Needs/Context/PRD/scenarios; BL-10 kiểm chứng M1, BL-11 đánh giá giả thuyết với người tham gia nếu có. Register GOV-REG-001 nối toàn bộ artefact/version/owner/evidence. [Decisions](decisions.md) D-12…18/OD-02…04 chứa assumptions; thay đổi phải cập nhật các cột liên quan, không tái dùng evidence version cũ.

Budget→EXT-01; Goals→EXT-02; Alerts→EXT-03; Assistant→EXT-04; EXT-05/FUT-05 mở rộng khác: out-of-scope, không UC/FR hoạt động. Sources/security real OD-05…07 pending; Agent quản lý dependency, PO cần chỉ định reviewer nguồn/security trước tích hợp. [Step2 review](evidence/step-2-review.md) là bằng chứng gate tài liệu; [Step1 review](evidence/step-1-review.md) giữ lịch sử. Không có screenshot prototype, API response/provider, PoC hoặc kết quả user test.
