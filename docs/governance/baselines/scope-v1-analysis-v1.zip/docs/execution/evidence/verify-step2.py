"""Check FinWeave step-2 documents and independent synthetic expected values.

This is document QA, not an application or provider/security test.
Run from any directory; writes only step-2-checks.json beside this script.
"""
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[3]
DOCS = ROOT / "docs"
checks = []


def read(path):
    return (ROOT / path).read_text(encoding="utf-8-sig")


def check(name, condition, detail=None):
    checks.append({"check": name, "pass": bool(condition), "detail": detail})
    if not condition:
        raise AssertionError(f"{name}: {detail}")


def table_rows(text, prefix):
    return [line for line in text.splitlines() if re.match(r"\| " + prefix, line)]


def expand(text, prefix):
    result = set()
    pattern = rf"(?<![A-Za-z0-9-]){prefix}-\d{{2}}(?:…\d{{2}})?(?:/\d{{2}}(?:…\d{{2}})?)*(?!\d)"
    for match in re.findall(pattern, text):
        for part in match[len(prefix) + 1:].split("/"):
            nums = part.split("…")
            a, b = int(nums[0]), int(nums[-1])
            result.update(f"{prefix}-{n:02}" for n in range(a, b + 1))
    return result


def functional_rows(text):
    result = {}
    for line in table_rows(text, "REQ-"):
        req = re.search(r"REQ-[A-Z]+-\d{2}\b", line)
        ac = re.search(r"AC-\d{2}\b", line)
        if req and ac:
            check("Unique functional row: " + req[0], req[0] not in result)
            result[req[0]] = (ac[0], line)
    return result


artefacts = [
    "docs/product/stakeholder-needs.md", "docs/requirements/context-model.md",
    "docs/product/operational-scenarios.md", "docs/product/prd.md",
    "docs/requirements/srs.md", "docs/product/use-cases.md",
    "docs/product/business-rules.md", "docs/data/data-requirements.md",
    "docs/requirements/glossary.md", "docs/execution/traceability.md",
]
check("Ten step-2 artefact files", all((ROOT / p).is_file() for p in artefacts))
for p in artefacts:
    t = read(p)
    check("Working baseline and review label: " + p,
          "analysis-v1" in t and "scope-v1" in t and "in-review" in t)

md_files = sorted(DOCS.rglob("*.md"))
links = 0
broken = []
for path in md_files:
    for target in re.findall(r"\[[^\]\n]+\]\(([^)\n]+)\)", path.read_text(encoding="utf-8-sig")):
        target = target.strip("<>").split("#", 1)[0]
        if not target or "://" in target or target.startswith("mailto:"):
            continue
        links += 1
        if not (path.parent / target).resolve().exists():
            broken.append(f"{path.relative_to(ROOT)} -> {target}")
check("Relative file links", not broken, {"count": links, "missing": broken})

register = read("docs/governance/artifact-register.md")
reg_ids = re.findall(r"^\| ((?:GOV|PRD|REQ|EXE|EVD|DAT)-[A-Z0-9-]+) \|", register, re.M)
check("Unique registered IDs", len(reg_ids) == len(set(reg_ids)), len(reg_ids))
registered_paths = set()
for target in re.findall(r"\[[^\]\n]+\]\(([^)\n]+)\)", register):
    if "://" not in target:
        registered_paths.add((DOCS / "governance" / target.split("#")[0]).resolve())
check("All document sources registered", all(p.resolve() in registered_paths for p in md_files), len(md_files))

scope = read("docs/product/scope.md")
srs = read("docs/requirements/srs.md")
rtm = read("docs/execution/traceability.md")
uc_text = read("docs/product/use-cases.md")
scn_text = read("docs/product/operational-scenarios.md")
rules = read("docs/product/business-rules.md")
data = read("docs/data/data-requirements.md")
baseline = functional_rows(scope)
spec = functional_rows(srs)
trace = functional_rows(rtm)
check("Baseline has exactly 18 functional requirements", len(baseline) == 18)
check("Unchanged REQ/AC pairing in SRS and RTM",
      {k: v[0] for k, v in baseline.items()} == {k: v[0] for k, v in spec.items()} == {k: v[0] for k, v in trace.items()})
check("Exactly 18 unique AC", {v[0] for v in baseline.values()} == {f"AC-{i:02}" for i in range(1, 19)})

uc_blocks = re.split(r"^## (UC-[A-Z]+-\d{2}) — .+$", uc_text, flags=re.M)
ucs = dict(zip(uc_blocks[1::2], uc_blocks[2::2]))
scns = set(re.findall(r"^\| (SCN-[A-Z]+-\d{2}) /", scn_text, re.M))
edges = set(re.findall(r"^### (SCN-X\d{2}) —", scn_text, re.M))
brs = {re.search(r"BR-\d{2}", row)[0] for row in table_rows(rules, "BR-")}
drs = {re.search(r"DR-\d{2}", row)[0] for row in table_rows(data, "DR-")}
nfrs = {re.search(r"NFR-\d{2}", row)[0] for row in table_rows(srs, "NFR-")}
check("18 UC, 18 primary SCN, 12 edge SCN", len(ucs) == 18 and len(scns) == 18 and len(edges) == 12)
check("24 rules / 15 data groups / 11 NFR", len(brs) == 24 and len(drs) == 15 and len(nfrs) == 11)
for uc, body in ucs.items():
    check("Required use-case fields: " + uc, all(field in body for field in [
        "Actor:", "Mục tiêu:", "Trigger:", "Precondition:", "Luồng chính:",
        "Alternative/error flows", "Business rules:", "Dữ liệu liên quan:", "Postcondition:",
    ]))
    check("Use-case trace and typed rules/data: " + uc,
          bool(re.search(r"REQ-[A-Z]+-\d{2}", body)) and bool(re.search(r"AC-\d{2}", body))
          and bool(expand(body, "BR")) and bool(expand(body, "DR")))
all_trace_brs, all_trace_drs = set(), set()
for req, (ac, row) in trace.items():
    uc_refs = set(re.findall(r"UC-[A-Z]+-\d{2}", row))
    scn_refs = set(re.findall(r"SCN-[A-Z]+-\d{2}|SCN-X\d{2}", row))
    br_refs, dr_refs = expand(row, "BR"), expand(row, "DR")
    check("RTM IDs/coverage: " + req,
          uc_refs and uc_refs <= ucs.keys() and scn_refs and scn_refs <= scns | edges
          and br_refs and br_refs <= brs and dr_refs and dr_refs <= drs
          and "planned" in row and "EVD-S2-001" in row)
    for uc in uc_refs:
        check("REQ/AC match use case: " + req, req in ucs[uc] and ac in ucs[uc])
    all_trace_brs |= br_refs
    all_trace_drs |= dr_refs
check("No orphan rule/data group", all_trace_brs == brs and all_trace_drs == drs)
check("All NFR mapped in RTM", nfrs == {re.search(r"NFR-\d{2}", row)[0] for row in table_rows(rtm, "NFR-")})
for path in artefacts:
    body = read(path)
    check("No undefined rule/data references: " + path,
          expand(body, "BR") <= brs and expand(body, "DR") <= drs,
          {"rules": sorted(expand(body, "BR") - brs), "data": sorted(expand(body, "DR") - drs)})
check("Independent business state axes", all(axis in rules for axis in [
    "Posting / Event", "Reconciliation / Event", "Categorization / Event",
    "Connection / Source", "Import / Job", "Review / Case", "Quality / holding/quote/source",
]))
for module in ["Budget", "Goals", "Alerts", "Assistant"]:
    check("Excluded module explicit: " + module, module in scope and module in read("docs/product/prd.md"))

# Independent arithmetic from source events, never from an application engine.
D = Decimal
balances = {"bank": D(20_000_000), "wallet": D(0), "cash": D(2_000_000)}
events = [
    ("income", {"bank": D(10_000_000)}),
    ("transfer", {"bank": D(-2_000_000), "wallet": D(2_000_000)}),
    ("transfer", {"bank": D(-1_000_000), "cash": D(1_000_000)}),
    ("expense", {"cash": D(-150_000)}),
    ("expense", {"wallet": D(-250_000)}),
    ("expense", {"bank": D(-600_000)}),
    ("refund", {"bank": D(200_000)}),
    ("expense", {"bank": D(-100_000)}),
]
income = gross = refund = D(0)
for kind, effects in events:
    for account, amount in effects.items():
        balances[account] += amount
        if kind == "income": income += amount
        if kind == "expense": gross -= amount
        if kind == "refund": refund += amount
cash_total = sum(balances.values())
baseline_numbers = {
    **balances, "cashTotal": cash_total, "income": income, "gross": gross,
    "refund": refund, "net": gross - refund, "flow": cash_total - D(22_000_000),
    "assets": cash_total + D(100)*D(50_000) + D(5)*D(8_000_000),
    "assetsRepriced": cash_total + D(100)*D(55_000) + D(5)*D(8_200_000),
    "scopeExWalletCash": balances["bank"] + balances["cash"],
    "scopeExWalletFlow": balances["bank"] + balances["cash"] - D(22_000_000),
}
fixed_oracle = [26_500_000, 1_750_000, 2_850_000, 31_100_000, 10_000_000,
                1_100_000, 200_000, 900_000, 9_100_000, 76_100_000,
                77_600_000, 29_350_000, 7_350_000]
check("Independent baseline equals Playbook oracle", list(baseline_numbers.values()) == list(map(D, fixed_oracle)))
for number in fixed_oracle:
    printed = format(number, ",").replace(",", ".")
    check("Oracle value present in scenarios: " + printed, printed in scn_text)
check("Category totals", D(150_000)+D(250_000)+D(600_000)+D(100_000) == gross)
check("No monetary effect from quote update", baseline_numbers["assetsRepriced"] - baseline_numbers["assets"] == D(1_500_000))
check("Gold unit and synthetic international FX", D("0.5")*D(80_000_000) == D(5)*D(8_000_000) == D("0.5")*D(3200)*D(25000))
check("Rounding and null distinct", D("0.45").quantize(D(1), rounding=ROUND_HALF_UP) == 0 and D("0.5").quantize(D(1), rounding=ROUND_HALF_UP) == 1)
check("Opening/reversal", D(2_000_000)-D(150_000)+D(150_000) == D(2_000_000))
check("One-sided then completed transfer", D(20_000_000)-D(1_000_000)+D(2_000_000) == D(21_000_000) and D(21_000_000)+D(1_000_000) == D(22_000_000))
check("Transfer with fee", D(20_000_000)-D(1_000_000)-D(10_000)+D(3_000_000) == D(21_990_000))
check("Cross-period refund", cash_total-refund == D(30_900_000) and D(0)-refund == D(-200_000))
check("Multiple refund / excess pending", refund+D(100_000) == D(300_000) and refund+D(100_000)+D(400_000) > D(600_000))
check("Cash count variance / adjustment", D(2_800_000)-balances["cash"] == D(-50_000) and cash_total-D(50_000) == D(31_050_000))
check("Linked purchase preserves assets", cash_total-D(500_000)+D(110)*D(50_000)+D(40_000_000) == baseline_numbers["assets"])
check("Missing gold known subtotal", cash_total+D(5_000_000) == D(36_100_000))
check("Posted correction signed sum", balances["cash"]+D(150_000)-D(120_000) == D(2_880_000) and gross-D(150_000)+D(120_000) == D(1_070_000))
check("Source revision delta", balances["bank"]-D(20_000) == D(26_480_000) and gross+D(20_000)-refund == D(920_000))
for edge, tokens in {
    "SCN-X03": ["bank19m", "cash2m", "tổng21m", "flow−1m"],
    "SCN-X04": ["Bank18,99m", "tổng21,99m", "flow−10k"],
    "SCN-X05": ["bank26,3m", "tổng30,9m", "net−200k", "flow+200k"],
    "SCN-X06": ["bank26,6m", "refund300k", "net800k", "refund0/net1,1m"],
    "SCN-X07": ["cash2,8m", "tổng31,05m", "net900k", "net950k"],
    "SCN-X08": ["Bank26m", "tiền30,6m", "assets76,1m", "flow8,6m"],
    "SCN-X09": ["subtotal36,1m", "total null"],
    "SCN-X10": ["bank26,48m", "gross1,12m", "net920k"],
    "SCN-X11": ["cash2,88m", "Payload130k", "conflict"],
}.items():
    section = re.split(rf"^### {edge} — .+$", scn_text, flags=re.M)[1].split("\n### ", 1)[0]
    check("Branch expected values documented: " + edge, all(token.casefold() in section.casefold() for token in tokens))

source_hashes = {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in [
    "FinWeave_Ideas.md", "FinWeave_Agent_Execution_Playbook.md", "FinWeave_Human_Setup_and_Prompts.md",
]}
results = {
    "result": "PASS", "runDate": "2026-10-05", "timezone": "Asia/Saigon",
    "evidenceType": "document_structure_and_independent_synthetic_arithmetic_only",
    "counts": {"markdownDocuments": len(md_files), "relativeLinks": links,
               "registeredIds": len(reg_ids), "FR": len(baseline), "AC": 18,
               "UC": len(ucs), "primaryScenarios": len(scns), "edgeScenarios": len(edges),
               "rules": len(brs), "dataGroups": len(drs), "NFR": len(nfrs), "checks": len(checks)},
    "independentOracleVND": {k: str(v) for k,v in baseline_numbers.items()},
    "sourceSHA256AtReview": source_hashes, "checks": checks,
    "limitations": ["No application test", "No user research", "No provider verification",
                    "No security PoC", "No independent reviewer or PO sign-off"],
}
output = Path(__file__).with_name("step-2-checks.json")
output.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"result": "PASS", **results["counts"]}, ensure_ascii=False))
