# FinWeave — Software Requirements Specification

ID REQ-SRS-001 · v1.0 · analysis-v1 trên scope-v1 · 05/10/2026 · in-review. Agent owner/self-review; PO pending external review. Nguồn [PRD](../product/prd.md), [Scope](../product/scope.md) và Ideas; giữ nguyên 18 ID REQ/AC. “Phải” dưới đây là mục tiêu hành vi chưa triển khai; không nghĩa app verified. 18 FR là diễn giải baseline, NFR bổ sung đo/đánh giá chất lượng cùng scope, không thêm module.

## Functional requirements

| Requirement / P0 M1 | Hành vi phải có và điều kiện lỗi chính | AC / UC / Rules / Data |
|---|---|---|
| REQ-SET-01 | Thiết lập mốc/workspace demo VND/+07/kỳ; opening tách income; lần sau mở Tổng quan thẳng. Date invalid/future chặn, cancel không thay settings | AC-01; UC-SET-01; BR-01/03/04; DR-01/02/14 |
| REQ-BANK-01 | Tạo bank và wallet tên/loại/opening/date/source; zero khai báo khác missing; validate tên/amount/date, preview/hủy; không xóa history khi archive | AC-02; UC-BANK-01; BR-02/04/20; DR-02/07/08 |
| REQ-CASH-01 | Tạo ví cash opening tự khai báo; balance calculated riêng observation; chưa count là unknown, không 0. Opening missing có nhãn, không báo tổng đầy đủ | AC-03; UC-CASH-01; BR-02/04/14; DR-02/12 |
| REQ-STOCK-01 | Khai báo ticker+market, quantity/date, optional cost basis; quote riêng source/unit/time; thiếu market/quantity âm chặn, không cost thì gain/loss unknown | AC-04; UC-STOCK-01; BR-02/15/18; DR-03/04/11 |
| REQ-GOLD-01 | Khai báo product/purity/unit/quantity/date, quote tương thích; đổi display5 chỉ↔0,5 lượng cùng40m; international giữ nhãn/FX. Sai loại/unit/FX missing chưa định giá | AC-05; UC-GOLD-01; BR-02/15/16; DR-03/04/11 |
| REQ-INPUT-01 | CSV demo profile/mapping/account; validate→preview→confirm selected valid subset all-or-none mô phỏng; lỗi/ambiguous giữ staging/Review sau confirm; cancel không mutation; retry cùng key không duplicate | AC-06; UC-IMPORT-01; BR-09/10/11; DR-06/07/09/10/13/15 |
| REQ-INPUT-02 | Nguồn notification/quote demo rõ capability/status/time/action; dummy connection, refresh/retry/disconnect; source/quote lỗi/cũ/revoked không giá0, quote không tự quantity update | AC-07; UC-SOURCE-01; BR-18/22; DR-06/11/13 |
| REQ-MONEY-01 | Nhập thu/chi/transfer/fee/refund; bắt buộc money/account/date, amount>0; preview/confirm/cancel; transfer hai legs và fee riêng, refund ngày nhận/link riêng, một phía/mơ hồ tạo Review | AC-08; UC-MONEY-01; BR-02…09; DR-02/07/08/09/10/15 |
| REQ-CASH-02 | Count cùng mốc/currency/type, variance trước/after; không auto expense; bổ sung event hoặc xác nhận adjustment reason/history. Cancel count resolution không đổi money | AC-09; UC-CASH-02; BR-14; DR-02/07/08/10/12 |
| REQ-HOLD-01 | Cập nhật quantity/date/reason và quote độc lập; giữ movements; correction không sinh tiền/thu–chi. Ví dụ purchase đủ evidence linked investment money+quantity, không chi sinh hoạt; invalid/version conflict chặn | AC-10; UC-HOLD-01; BR-13/15/16/17/18; DR-04/05/07/08/11/14 |
| REQ-TXN-01 | Filter kỳ/account/type/category/posting/reconciliation; detail money/date/account/evidence/history; pending riêng; no results empty, error retry giữ filters, không amount bằng0 thay missing | AC-11; UC-TXN-01; BR-03/05/12/19; DR-06/07/08/09/14 |
| REQ-TXN-02 | Sửa draft, category override, posted adjust preview/reason/version; giữ original+reversal/replacement; reimport không override user; stale version/timeout xử lý có kết quả một lần | AC-12; UC-TXN-02; BR-09/12/13; DR-06…10/15 |
| REQ-TRACK-01 | Tổng quan tiền/income/gross/refund/net/cashflow/assets theo chung snapshot/scope/asOf/versions; visual có period/unit/table. Missing/stale có nhãn, không net-worth đầy đủ; khớp oracle | AC-13; UC-OVERVIEW-01; BR-03…08/17/18/19; DR-02/04/07/08/11/14 |
| REQ-TRACK-02 | Chart drill tới filters tương ứng/holding và Back giữ context; toggle scope/archive giữ history, ranh giới transfer được giải thích. Version stale refresh hoặc nêu changed, không chi tiết lệch snapshot âm thầm | AC-14; UC-DRILL-01; BR-06/19/20; DR-02/04/07/14/15 |
| REQ-REVIEW-01 | Cases thiếu/trùng/transfer/refund/category/pending/balance: evidence/căn cứ/preview/actions theo loại, confirmed/refused/supplement/cancel/defer; retry case resolved delta0; thiếu phía không fake received | AC-15; UC-REVIEW-01; BR-05…14/21; DR-06…10/12/15 |
| REQ-REVIEW-02 | Case quality holdings/price/FX/compatibility/source; separate dates/actions update/reconnect/refuse/defer; keep old quote labeled; no accuracy% hoặc user-declared thành verified | AC-16; UC-REVIEW-02; BR-15/16/18/19/21/22; DR-03…06/10/11/14 |
| REQ-UX-01 | Tiếng Việt web desktop/mobile/keyboard, focus/dialog/errors/table, reduced motion nếu có animation; masking toàn bộ giá trị nhạy cảm; lỗi không chỉ màu, không clipping | AC-17; UC-UX-01; BR-23; DR-14/15 |
| REQ-DEMO-01 | Nhãn synthetic/date/price, mở local theo hướng dẫn bước 3, scenario/reset complete; reset không key thật/real data, không nút optional gây hiểu sai; không persistence claim backend | AC-18; UC-DEMO-01; BR-24; DR-01…15 |

## Non-functional requirements

Tất cả ngưỡng đề xuất chưa đo. Owner chuẩn bị/check: AG; PO review mục tiêu; reviewer nguồn/security thật chưa chỉ định, phải có trước gate tương ứng. [Scenarios](../product/operational-scenarios.md) và [RTM](../execution/traceability.md) map NFR riêng, không trộn evidence sản phẩm với review tài liệu.

| ID / loại / mức | Yêu cầu và tiêu chí kiểm chứng | Cách đánh giá / thời điểm / căn cứ |
|---|---|---|
| NFR-01 / correctness / M1→M3 | Tất cả giá trị oracle/nhánh kỳ/phạm vi khớp chính xác VND và không float; số liệu cùng versions nhất quán; missing không 0 | M1 walkthrough18 AC/SCN-X01…09; M2 test/mock; M3 reconciliation independent. BR-02…19, DR-14; hiện chỉ tính độc lập expected |
| NFR-02 / accessibility / M1/M2 | AC-17: mọi action keyboard, focus visible/trap/return dialog, label và lỗi chữ, chart table, không màu đơn lẻ; masking không lộ ở accessible text | Walkthrough SCN-UX-01 tại bước 3; accessibility audit bước6, chưa chứng nhận tiêu chuẩn/WCAG nào |
| NFR-03 / responsive/localization / M1/M2 | Việt nhất quán, VND/unit/date +07, viewport1440×900/390×844/360px; không page overflow ngang/clipped, table có container scroll nếu cần | SCN-UX-01 ảnh/keyboard bước 3; coverage NFR này không thay user research |
| NFR-04 / reliability / M1→M3 | Không báo success trước kết quả; validation/offline/timeout/conflict giữ input và retry/cancel; rapid double confirm/retry không hiệu ứng tiền lần2; lỗi commit không half selected batch | SCN-X11 + import/money/review; M1 states mô phỏng; M2 mock fault; M3 timeout-after-commit/worker/concurrency thật, không claimed exactly-once |
| NFR-05 / traceability/transparency / M1→M3 | 18/18 FR và AC có UC/SCN/rules/data; mọi metrics có snapshot/period/scope/asOf/versions/provenance, mọi unsupported/unknown/self-declared/stale có nhãn | Rà RTM/links hiện tại; prototype drill-down bước 3; lineage/test bước7/8. BR-18…24 |
| NFR-06 / reproducibility / M1/M2 | Reset trở về fixture/scenario/filter/version deterministic; lặp sequence cùng input cho cùng expected; clock giả không theo ngày máy; storage demo phải được mô tả khi xây | SCN-DEMO-01/OVERVIEW-01; DR-15; bước 3/6. Hồ sơ hiện spec, chưa chạy reset app |
| NFR-07 / privacy/secrets / M1→M3 | M1 chỉ synthetic và dummy keys, không real finance vào repo/log/chat/LLM; masking không thay encryption. M2 contracts phải nêu encrypted transport tới boundary, workspace supplied không chứng minh quyền | Review tài liệu/fixture bước 2/3; contract bước4. M3 audit artifacts/DB/gateway/queue/log/backup/response/secret handling theo Ideas15–16; OD-07 unresolved |
| NFR-08 / ownership & anti-Ops / M3 gate | Admin/Ops/DBA/support không đọc finance, giả mạo user/device/recovery, tự sửa code/client/key policy để giải mã. Tenant checks cả refs/source/report; workload attestation + tách quyền theo trust model. Nếu chưa đạt, chỉ synthetic experimental integration | OD-07/FUT-02; PoC threat-driven trước transport/real data, evidence bước7/8/9. Chưa có PoC/approval; demo denied SCN-X12 không chứng minh requirement này |
| NFR-09 / usability / M1 | Mọi tác vụ lõi hoàn thành trong mô phỏng, lỗi nghiêm trọng hiểu sai/mất tác vụ =0 chưa xử lý; mục tiêu 18/18 AC. Chưa có người thì chỉ AG walkthrough | Bước3 SCN01…18; BL-10/11, OD-01/A-04; ≥4/5 người chỉ đề xuất nếu có user test, chưa đo |
| NFR-10 / source quality / M1→M3 | Tách quantity/price/source freshness; no false realtime/coverage; quote compatible/FX/time rõ; M1 dùng OD thresholds demo, M3 provider chỉ advertised sau quyền/license/mẫu đo | SCN-SOURCE-01/REVIEW-02/X09; BR-15…22; OD-02/04 giả định, OD-05/06 chưa provider verification |
| NFR-11 / performance / M1, kế thừa M2/M3 | Giả định mục tiêu local demo20 rows: phản hồi filter/preview/render≤1s, state “đang xử lý” cho mô phỏng chờ>1s, không khóa Back/cancel; đo tối thiểu10 lượt sau warm-up ghi máy/browser/fixture và max elapsed. Đây không production SLA | Bước3 SCN-UX-01/IMPORT-01/TXN-01; PO review ngưỡng D-18. Server latency/capacity/SLO chưa chốt, cần benchmark workload+crypto ở bước8/9, không suy từ demo |

## Ràng buộc, states và nghiệm thu

State machine nghiệp vụ nguồn duy nhất ở [Rules §Các trục trạng thái](../product/business-rules.md); dictionary ở [Data](../data/data-requirements.md); không thêm status trộn các trục. UC lỗi chung và từng nhánh ở [Use Cases](../product/use-cases.md). OD-02…04 defaults là giả định được phép dùng để tiếp tục, không approved provider/market policy. D-13…18 giữ alternatives và impact. Không OpenAPI/DB schema, research results, provider verification hoặc security PoC ở bước 2.

M1 FR/NFR vẫn `planned`; tài liệu có thể self-reviewed ở bước 2. Formal sign-off pending; chưa đạt M1/M2/M3. Tiêu chí bước 2 là DoD hồ sơ, [gate review](../execution/evidence/step-2-review.md) sau kiểm tra. Scope/AC có quyền cao hơn diễn giải SRS; nếu mâu thuẫn phải ghi decisions và sửa hồ sơ trước gate.
