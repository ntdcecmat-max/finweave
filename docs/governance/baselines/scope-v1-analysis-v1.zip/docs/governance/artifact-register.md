# FinWeave — Artifact Register

Cập nhật 05/10/2026 (Asia/Saigon). ID: GOV-REG-001; version 1.1. Nguồn quản trị: [Playbook §3.4–3.7](../../FinWeave_Agent_Execution_Playbook.md). Register này đăng ký nguồn sự thật; không biến hồ sơ thành bằng chứng sản phẩm.

## Quy ước trách nhiệm và baseline

AG = Agent thực hiện, owner tài liệu và reviewer tự rà soát. PO = chủ sản phẩm (user giao nhiệm vụ), reviewer/approver bên ngoài **pending external review**; chưa có sign-off. AG không phải reviewer độc lập. Các owner nguồn/security tương lai chưa được chỉ định: AG chỉ theo dõi dependency, PO cần chỉ định trước tích hợp.

`scope-v1` là baseline làm việc bước 1 theo nhiệm vụ, ngày 05/10/2026; `baselined` không có nghĩa approved bởi PO. S1 = v1.0 / scope-v1; S1r = v1.1 / scope-v1 (sửa quản trị, không thay 18 REQ/AC/oracle). S2 = v1.0 / analysis-v1, kế thừa scope-v1, giả định OD-02/03/04. Trạng thái artefact theo Playbook (draft/in-review/baselined…), khác trạng thái triển khai planned/verified trong progress/RTM. M1 là mức chuẩn bị hiện tại; M2/M3 chỉ là nguồn kế thừa có điều kiện.

## Artefact bước 1 đã có

| Artifact ID | Bước | Tên / đường dẫn | Mục đích / phạm vi | Owner / reviewer / approver | Mức | Trạng thái | Version / baseline | Nguồn / phụ thuộc | Truy vết / ghi chú |
|---|---|---|---|---|---|---|---|---|---|
| PRD-VIS-001 | 1 | [Product Vision](../product/product-vision.md) | Giá trị và hướng bốn nhóm lõi | AG / AG + PO pending / PO pending | M1; kế thừa M2/M3 | baselined | S1 | Ideas; D-02/03 | UP-01…05; REQ; EVD-S1-001 |
| PRD-PRO-001 | 1 | [Problem Statement](../product/problem-statement.md) | Vấn đề giả định cần kiểm chứng | AG / AG + PO pending / PO pending | M1 | baselined | S1 | Ideas; A-01…03 | UP-01…05; EVD-S1-001 |
| PRD-VAL-001 | 1 | [Value Proposition](../product/value-proposition.md) | Benefit → chức năng → đánh giá | AG / AG + PO pending / PO pending | M1 | baselined | S1 | Vision/Problem/Scope | 18 REQ/AC; EVD-S1-001 |
| GOV-CHA-001 | 1,2 | [Project Charter](../product/project-charter.md) | Quyền, trách nhiệm và gate | AG / AG + PO pending / PO pending | M1 | baselined | S1r | Nhiệm vụ; Playbook | D-01/D-12; EXE-PLAN-001 |
| PRD-SCP-001 | 1,2 | [Scope](../product/scope.md) | Matrix 4×5; 18 REQ/AC, oracle, exclusions | AG / AG + PO pending / PO pending | M1; hướng M2/M3 | baselined | S1r | Ideas/Playbook §13; D-02…07 | REQ/AC; REQ-RTM-001; thay quản trị, giữ nghĩa baseline |
| PRD-FEA-001 | 1,2 | [Feasibility Study](../product/feasibility-study.md) | Khả thi sơ bộ, dependency chưa kiểm chứng | AG / AG + PO pending / PO pending | M1; hướng M2/M3 | baselined | S1r | DEP-01…04; OD-05…07 | FUT-01…04; EVD-S1-001; cập nhật quyền nhiệm vụ, chưa PoC/provider |
| PRD-OPT-001 | 1 | [Options Analysis](../product/options-analysis.md) | Lựa chọn bàn giao local M1 | AG / AG + PO pending / PO pending | M1 | baselined | S1 | D-04/08; Scope | BL-07…10; EVD-S1-001 |
| PRD-CST-001 | 1,2 | [Cost Model](../product/cost-model.md) | Effort và biến chi phí, không báo giá | AG / AG + PO pending / PO pending | M1; hướng M2/M3 | baselined | S1r | EST-01; D-11/12 | Roadmap; EVD-S1-001; đồng bộ tên gói bước 2, chưa actual |
| GOV-ASM-001 | 1,2 | [Assumptions/Constraints](../product/assumptions-constraints.md) | Ràng buộc và giả định có hạn xử lý | AG / AG + PO pending / PO pending | M1; kế thừa | baselined | S1r | Decisions; Scope | A-01…04; OD-01…07; CON-01…08 |
| GOV-RSK-001 | 1 | [Risk Register](../product/risk-register.md) | Trigger, owner và biện pháp rủi ro | AG / AG + PO pending / PO pending | M1; hướng M2/M3 | baselined | S1 | Scope; DEP; A/OD | Backlog; EVD-S1-001 |
| PRD-RDM-001 | 1,2 | [Roadmap](../product/roadmap.md) | Mốc theo gate, không lịch cam kết | AG / AG + PO pending / PO pending | M1/M2/M3 | baselined | S1r | Playbook; Scope; Backlog | RDM-01…05; FUT/EXT |
| EXE-BKL-001 | 1,2 | [Backlog](../product/backlog.md) | Priority, phụ thuộc, output, trạng thái | AG / AG + PO pending / PO pending | M1; hướng M2/M3 | in-review | S1r | Scope; Playbook; D-12 | BL-01…11; FUT/EXT/DEP |
| EXE-IDX-001 | 1,2 | [Mục lục](../product/README.md) | Điều hướng hồ sơ | AG / AG / không cần approval riêng | M1 | in-review | S1r | Các artefact product | Register/RTM/evidence |
| EXE-PLAN-001 | 1,2 | [Plan](../execution/plan.md) | Quyền, thứ tự, DoR/DoD | AG / AG + PO pending / PO pending | M1 | in-review | S1r | User; Playbook; D-12 | BL-02…06; gói bước 2 |
| EXE-PRG-001 | 1,2 | [Progress](../execution/progress.md) | Tiến độ thực tế và giới hạn | AG / AG / PO pending gate | M1 | in-review | S1r | Review evidence | EVD-S1-001; gate bước 2 |
| GOV-DEC-001 | 1,2 | [Decisions](../execution/decisions.md) | Quyết định/giả định/tác động | AG / AG + PO pending / PO pending | M1; kế thừa | in-review | S1r | User; Ideas; Playbook | D/A/OD; Scope/Rules/RTM |
| REQ-RTM-001 | 1,2 | [RTM](../execution/traceability.md) | Need/FR/NFR → UC/rule/data/scenario → design/test/evidence | AG / AG + PO pending / PO pending | M1; hướng M2/M3 | in-review | S2; RTM bước 1 v1.0/scope-v1 superseded cùng path | 18 REQ/AC; Ideas; bộ bước 2 | UC/SCN đặc tả; screen/API/test planned; EVD-S2-001 chỉ hồ sơ |
| EVD-S1-001 | 1 | [Step 1 Review](../execution/evidence/step-1-review.md) | Kết quả rà soát lịch sử bước 1 | AG / AG / PO pending | M1 chuẩn bị | baselined | S1; giữ nguyên báo cáo lịch sử | Bộ bước 1; oracle | Tài liệu verified; chưa M1 |

## Gói artefact bước 2 và hồ sơ review

| Artifact ID | Bước | Tên / đường dẫn | Mục đích / phạm vi | Owner / reviewer / approver | Mức | Trạng thái | Version / baseline | Nguồn / phụ thuộc | Truy vết / ghi chú |
|---|---|---|---|---|---|---|---|---|---|
| PRD-NEED-001 | 2 | [Stakeholder Needs](../product/stakeholder-needs.md) | SN-01…08 giả định và nhu cầu quản trị | AG / AG + PO pending / PO pending | M1; hướng M2/M3 | in-review | S2 | Problem/Scope; A-01…04 | SN→REQ/AC; RTM; chưa research |
| REQ-CTX-001 | 2 | [Context Model](../requirements/context-model.md) | Actors, boundary,6 interfaces và future boundary | AG / AG + PO pending / PO pending | M1; hướng M2/M3 | in-review | S2 | Scope/Needs/Ideas19 | IF→REQ/UC/DR; không HLD |
| REQ-SCN-001 | 2 | [Operational Scenarios](../product/operational-scenarios.md) | 18 SCN+12 edges; reset và independent expected | AG / AG + PO pending / PO pending | M1; kế thừa | in-review | S2 | Playbook13;18 AC;BR/DR;OD-02…04 | UC/AC/O-01…10; EVD-S2-001; chưa fixture app |
| PRD-001 | 2 | [PRD](../product/prd.md) | Mục tiêu/benefit/scope/quality/dependencies | AG / AG + PO pending / PO pending | M1; kế thừa | in-review | S2 | Scope/Needs/Context | SRS/UC/RTM; không scope mới |
| REQ-SRS-001 | 2 | [SRS FR/NFR](../requirements/srs.md) | 18 FR/11 NFR kiểm chứng được theo mức | AG / AG + PO pending / PO pending | M1; hướng M2/M3 | in-review | S2 | Scope/PRD;Ideas;D-13…18 | REQ/AC/NFR→UC/SCN/BR/DR; chưa triển khai |
| REQ-UC-001 | 2 | [Use Cases](../product/use-cases.md) | 18 UC đủ actor/trigger/pre/main/alt/errors/rules/data/post | AG / AG + PO pending / PO pending | M1; kế thừa | in-review | S2 | SRS/Scope;BR/DR | UC→SCN/AC; CF-01…04; chưa walkthrough app |
| REQ-BR-001 | 2 | [Business Rules Catalogue](../product/business-rules.md) | 24 rules testable, states riêng | AG / AG + PO pending / PO pending | M1; kế thừa | in-review | S2 | Ideas1.5…1.12;Scope;D-13…18 | BR→SCN/DR; assumptions labeled |
| DAT-REQ-001 | 2 | [Data Requirements](../data/data-requirements.md) | 15 data groups/dictionary/relations/quality/lineage | AG / AG + PO pending / PO pending | M1; hướng M2/M3 | in-review | S2 | Scope/BR;Ideas1.9 | DR→UC/BR/SCN; không DB/API schema |
| REQ-GLO-001 | 2 | [Glossary](../requirements/glossary.md) | Nghĩa thuật ngữ và nhãn UI Việt | AG / AG + PO pending / PO pending | M1; kế thừa | in-review | S2 | Scope/BR/DR | PRD/SRS/UC/RTM dùng chung |
| EVD-S2-001 | 2 | [Step2 Review](../execution/evidence/step-2-review.md) | Kết quả structural/numerical/manual review và gate | AG / AG self-review / PO pending | M1 chuẩn bị | in-review | S2 | Bộ bước 2; verification script+JSON | Tài liệu verified; chưa M1/research/provider/PoC |
| GOV-REG-001 | 1,2 | [Artifact Register](artifact-register.md) | Catalogue nguồn sự thật/version/trách nhiệm | AG / AG + PO pending / PO pending | M1; kế thừa | in-review | v1.1/scope-v1+analysis-v1 | Playbook3.4; toàn bộ artefact | EXE/RTM/EVD; không sign-off |

RTM là artefact thứ10 của gói bước 2, nằm trong bảng cập nhật bước 1 ở trên, **không tạo RTM thứ hai**. Script và JSON kiểm tra là attachments của EVD-S2-001, không artefact phân tích mới. Không tạo Research Results/Supplier Verification/Security PoC trống hoặc giả để đủ số.

## Nguồn điều khiển

[Ideas](../../FinWeave_Ideas.md), [Playbook](../../FinWeave_Agent_Execution_Playbook.md), [Human Setup](../../FinWeave_Human_Setup_and_Prompts.md) là nguồn do user cung cấp, owner PO; AG chỉ đọc, không tự sửa hay tuyên bố xác minh provider trong nguồn. Nhiệm vụ chat 05/10/2026 cho phép bước 2 và sử dụng giả định OD-02/03/04; liên kết nội bộ qua D-12.

## Lịch sử thay đổi

- 05/10/2026 v1.0: đăng ký đầy đủ 18 artefact hồ sơ bước 1 đã có trước phân tích bước 2; nguồn/owner/baseline/truy vết/giới hạn rõ. Các cập nhật quản trị ở cùng file thay phiên bản cũ, không có hai nguồn sự thật có hiệu lực. Không có artefact bị xóa hoặc retired.
- 05/10/2026 v1.1: bổ sung gói bước 2 (9 artefact mới + RTM cập nhật), review evidence; catalogue 29 nguồn Markdown gồm register. S1 v1.0 của Scope/Charter/Assumptions/Roadmap/Backlog/Index/Plan/Progress/Decisions/Feasibility/Cost superseded **phần quản trị** bởi S1r v1.1 cùng path; 18 REQ/AC/oracle không đổi. RTM cũ superseded toàn bảng mapping bởi S2, sản phẩm vẫn planned. Formal approval pending external review.
